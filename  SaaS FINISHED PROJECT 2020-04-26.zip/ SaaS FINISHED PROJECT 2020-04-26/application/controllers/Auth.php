	<?php
defined('BASEPATH') OR exit('No direct script access allowed');
define('ROOTDIR', 'C:/xampp/htdocs/assignment');

class Auth extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('session');
	}
	public function index(){
		redirect(base_url('auth/login'));
		//
	}
	public function login(){
		if (!$this->session->userdata('jurusan')) {
			$this->load->view('login');	
		}
		else{	
			include APPPATH.'views/connect.php';
			$username=$this->session->userdata('username');
			$password=$this->session->userdata('password');
			$sql1="SELECT*FROM siswa WHERE username='$username' AND password='$password'";
			$q1=mysqli_query($conn,$sql1);
			$data=mysqli_fetch_assoc($q1);
			if ($this->session->userdata('level') == "kepala_bengkel") {
				redirect(base_url('kepala_bengkel/dashboard/').$this->session->userdata('jurusan'));
			}
			elseif ($this->session->userdata('level') == "pembimbing") {
				redirect(base_url('pembimbing/dashboard/').$this->session->userdata('jurusan'));
			}
			elseif ($this->session->userdata('level') == "siswa" && $data['tempat_pkl'] != NULL && $data['start_pkl'] != NULL && $data['finish_pkl'] != NULL && $data['pembimbing_perusahaan'] != NULL) {
				redirect(base_url('siswa/home/').$this->session->userdata('jurusan'));
			}
			elseif (!$data['tempat_pkl'] || !$data['start_pkl'] || !$data['finish_pkl'] || !$data['pembimbing_perusahaan'] ) {
				redirect(base_url('auth/before'));
			}
		}
	}
	public function proccess(){
		include APPPATH.'views/connect.php';
		$URI = $this->uri->segment(3);	
		if ($URI == 'login') {
			$button = $this->input->post('login');
			if (isset($button)) {
				$username=htmlspecialchars($this->input->post('username'));
				$password=htmlspecialchars($this->input->post('password'));
				$password=md5($password);

				$sql1="SELECT*FROM siswa WHERE username='$username' AND password='$password'";
				$sql2="SELECT*FROM pembimbing WHERE username_pembimbing='$username' AND password='$password'";
				$sql3="SELECT*FROM kepala_bengkel WHERE username_kepala_bengkel='$username' AND password='$password'";

				$q1=mysqli_query($conn,$sql1);
				$q2=mysqli_query($conn,$sql2);
				$q3=mysqli_query($conn,$sql3);

				$check1=mysqli_num_rows($q1);
				$check2=mysqli_num_rows($q2);
				$check3=mysqli_num_rows($q3);

				if ($check1 > 0 && $check2 == 0 && $check3 == 0) {
					$data=mysqli_fetch_assoc($q1);
					$data_session = array(
											'username'		=> $data['username'],
											'nama_lengkap'	=> $data['nama_lengkap'],
											'password'	 	=> $data['password'],
											'level' 		=> $data['level'],
											'jurusan'		=> $data['jurusan']
									 );
					$this->session->set_userdata($data_session);
					if (!$data['tempat_pkl'] || !$data['start_pkl'] || !$data['finish_pkl'] || !$data['pembimbing_perusahaan'] ) {
						redirect(base_url('auth/before'));
					}
					elseif ($data['tempat_pkl'] != NULL && $data['start_pkl'] != NULL && $data['finish_pkl'] != NULL && $data['pembimbing_perusahaan'] ) {
						redirect(base_url('siswa/home'));
					}
				}
				elseif ($check1 == 0 && $check2 > 0 && $check3 == 0) {
					$data=mysqli_fetch_array($q2);
					$data_session = array(
											'username'	=> $data['username_pembimbing'],
											'password' 	=> $data['password'],
											'level' 	=> $data['level'],
											'jurusan'	=> $data['jurusan']
									 );
					$this->session->set_userdata($data_session);
					redirect(base_url('pembimbing/dashboard/').$data['jurusan']);
				}
				elseif ($check1 == 0 && $check2 == 0 && $check3 > 0) {
					$data=mysqli_fetch_assoc($q3);
					$data_session = array(
											'username'	=> $data['username_kepala_bengkel'],
											'password' 	=> $data['password'],
											'level' 	=> $data['level'],
											'jurusan'	=> $data['jurusan']
									 );
					$this->session->set_userdata($data_session);
					redirect(base_url('kepala_bengkel/dashboard/').$data['jurusan']);
				}
				else{
					?>
					<script type="text/javascript">
						alert('Username atau Password yang Anda Masukkan Salah ! ');
						document.location.href="<?= base_url('auth/login') ?>";
					</script>
					<?php
				}
			}
		}
	}
	public function deleted(){
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		if ($URI == TRUE && $URI2 == TRUE) {
			if ($this->session->userdata('level') == 'kepala_bengkel' && $URI2 == $this->session->userdata('username')) {
				include APPPATH.'views/connect.php';

					$username_pembimbing=htmlspecialchars($URI);
					$data=array('username_pembimbing' => $username_pembimbing);
					$dbtable = 'pembimbing';
					$dir_guru=$username_pembimbing;
					$jurusan = $this->session->userdata('jurusan');
					
					$dir=ROOTDIR.'/'.$jurusan.'/'.$dir_guru;

					$p=scandir($dir);
					if (file_exists($dir.'/')) {
						$q="SELECT username FROM siswa WHERE username_pembimbing='$username_pembimbing' AND jurusan='$jurusan'";
						$qq=mysqli_query($conn,$q);
						$qqq=mysqli_num_rows($qq);
						while ($qqqe=mysqli_fetch_assoc($qq)) {
							$pe=scandir($dir.'/'.$qqqe['username'].'/');
							$co=count($pe);
							$n=2;
							if(file_exists($dir.'/'.$qqqe['username'].'/'.$pe[1]) && $pe[1] != NULL) {
								for ($i=$n; $i <$co ; $i++) { 
									unlink($dir.'/'.$qqqe['username'].'/'.$pe[$i]);
								}
								rmdir($dir.'/'.$qqqe['username']);
							}
						}
								rmdir($dir);
								$this->data->userdel($data,$dbtable);
								redirect(base_url('kepala_bengkel/pembimbing/'.$jurusan));
					}
			}
			else{
				redirect(base_url('kepala_bengkel/pembimbing/'.$jurusan));
			}
		}
		else{
			redirect(base_url('kepala_bengkel/pembimbing/'.$jurusan));	
		}
	}
	public function logout(){
		$this->session->sess_destroy();
		redirect(base_url('auth/login'));
	}
	public function before(){	
		if (!$this->session->userdata('jurusan')) {
			$this->load->view('login');	
		}
		else{	
			include APPPATH.'views/connect.php';
			$username=$this->session->userdata('username');
			$password=$this->session->userdata('password');
			$sql1="SELECT*FROM siswa WHERE username='$username' AND password='$password'";
			$q1=mysqli_query($conn,$sql1);
			$data=mysqli_fetch_assoc($q1);
			if ($this->session->userdata('level') == "kepala_bengkel") {
				redirect(base_url('kepala_bengkel/dashboard/').$this->session->userdata('jurusan'));
			}
			elseif ($this->session->userdata('level') == "pembimbing") {
				redirect(base_url('pembimbing/dashboard/').$this->session->userdata('jurusan'));
			}
			elseif ($this->session->userdata('level') == "siswa" && $data['tempat_pkl'] != NULL && $data['start_pkl'] != NULL && $data['finish_pkl'] != NULL && $data['pembimbing_perusahaan'] != NULL) {
				redirect(base_url('siswa/home/').$this->session->userdata('jurusan'));
			}
		}
		$this->load->view('login_before');
	}
	public function confirm(){
		$tombol=$this->input->post('confirm');
		if (isset($tombol)) {
			$username=$this->session->userdata('username');
			$jurusan=$this->session->userdata('jurusan');

			$tempat_pkl=$this->input->post('tempat_pkl');
			$alamat_pkl=$this->input->post('alamat_pkl');
			$pembimbing_perusahaan=$this->input->post('pembimbing_perusahaan');
			$start_pkl=$this->input->post('start_pkl');
			$finish_pkl=$this->input->post('finish_pkl');

		    date_default_timezone_set('Asia/Jakarta');
		    $datenow=date('Y-m-d');
			
			$assignment="assignment";
			$dbsiswa="siswa";
			$data_siswa=array(
								'tempat_pkl'			=> $tempat_pkl,
								'alamat_pkl'			=> $alamat_pkl,
								'pembimbing_perusahaan'	=> $pembimbing_perusahaan,
								'start_pkl'				=> $start_pkl,
								'finish_pkl'			=> $finish_pkl
								);
			$wheresiswa=array('username'	=>	$username);
			$wherejurusan=array('jurusan'	=>	$jurusan);


			if ($finish_pkl > $datenow || $finish_pkl < $start_pkl || $finish_pkl == $start_pkl ) {
				?>
				<script type="text/javascript">
					alert('Format Waktu Salah !');
					document.location.href="<?= base_url('auth/before') ?>";
				</script>
				<?php
			}
			elseif($finish_pkl > $start_pkl){

				$date_finish=str_split($finish_pkl);
				$year_finish = array($date_finish[0],$date_finish[1],$date_finish[2],$date_finish[3]);
				$month_finish = array($date_finish[5],$date_finish[6]);
				$day_finish = array($date_finish[8],$date_finish[9]);
				
				$tahun_finish_pkl=implode($year_finish, '');
				$bulan_finish_pkl=implode($month_finish, '');
				$hari_finish_pkl=implode($day_finish, '');
				
				if ($bulan_finish_pkl == 12) {
					$final_tahun_finish_pkl=$tahun_finish_pkl+1;
					$deadline_month='01';
					$hari_finish_pkl;

					$deadline_finally=array($final_tahun_finish_pkl,$deadline_month,$hari_finish_pkl);
					$finally=implode($deadline_finally,'-');
					
					$deadlinenya=array('deadline_pengumpulan'	=>	$finally);

					$this->data->update_deadline_assignment($assignment,$deadlinenya,$wheresiswa);
					$this->data->update_from_user($data_siswa,$dbsiswa,$wheresiswa,$wherejurusan);
					redirect(base_url('siswa/home'));

				}
				elseif ($bulan_finish_pkl < 12) {
					$tahun_finish_pkl;
					$deadline_month=$bulan_finish_pkl+1;
					$hari_finish_pkl;					
					
					$deadline_finally=array($tahun_finish_pkl,$deadline_month,$hari_finish_pkl);					
					$finally=implode($deadline_finally,'-');
					
					$deadlinenya=array('deadline_pengumpulan'	=>	$finally);

					$this->data->update_deadline_assignment($assignment,$deadlinenya,$wheresiswa);
					$this->data->update_from_user($data_siswa,$dbsiswa,$wheresiswa,$wherejurusan);
					redirect(base_url('siswa/home'));
				}
			}
		}
	}
}