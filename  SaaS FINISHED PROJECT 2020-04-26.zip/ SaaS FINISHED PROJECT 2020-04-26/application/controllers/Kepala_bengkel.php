<?php
defined('BASEPATH') OR exit('No direct script access allowed');
define('ROOTDIR', 'C:/xampp/htdocs/assignment');

class Kepala_bengkel extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
	}
	public function index(){
		$l=$this->session->userdata('level');
		$jurusan=$this->session->userdata('jurusann');
		$URI=$this->uri->segment(3);
		if ($l != 'kepala_bengkel') {
			redirect(base_url('auth/login'));
		}
		elseif ($URI == $jurusan) {
			redirect(base_url('kepala_bengkel/dashboard/').$jurusan);
		}
		else{
			$this->load->view('errir_page');
		}
	}
	public function profile(){
		$l=$this->session->userdata('level');
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		if ($l == 'kepala_bengkel' && $URI == $this->session->userdata('jurusan') && !$URI2) {
			$this->load->view('kabeng_profile');
		}
		elseif ($URI != $this->session->userdata('jurusan')) {
			redirect('Kepala_bengkel/profile/'.$this->session->userdata('jurusan'));
		}
		if ($URI == TRUE && $URI2 ==TRUE) {
			if ($URI2 == 'updated') {
				$edit = $this->input->post('ganti');
				if (isset($edit)) {
					$username=$this->session->userdata('username');
					$jurusan=$this->session->userdata('jurusan');
					$l=$this->session->userdata('level');
					$nama_lengkap		= htmlspecialchars($this->input->post('nama_lengkap'));
					$email				= htmlspecialchars($this->input->post('email'));
					$telepon			= htmlspecialchars($this->input->post('telepon'));
							
					
					$data  		= array(
										 'nama_lengkap' => $nama_lengkap, 
										 'email'		=> $email,
										 'telepon'		=> $telepon
										);
					$where 	= array('username_kepala_bengkel' => $username);
					$where2 = array( 'jurusan' => $jurusan);
					$dbtable	= $l;	
					$this->data->update_user($data,$where,$where2,$dbtable);
					redirect(base_url('Kepala_bengkel/profile/'.$this->session->userdata('jurusan')));
				}
				else{
					$this->load->view('errir_page');
				}
			}
			elseif ( $URI2 == 'foto_updated') {
				echo "foto_updated";
				include APPPATH.'views/connect.php';
				$username=$this->session->userdata('username');
				$jurusan=$this->session->userdata('jurusan');

		        $config['upload_path']          = './user_img/';
		        $config['allowed_types']        = 'gif|jpg|png|jpeg';
		        $config['max_size']             = 5000;
		        $config['file_name']            = 'IMG_'.date('Ymd-His').'_'.$username;

		        $this->load->library('upload', $config);

		        if ( ! $this->upload->do_upload('foto'))
		        {
		                redirect(base_url('Kepala_bengkel/profile/'.$jurusan));
		        }
		        else
		        {
		                $que=mysqli_query($conn,"SELECT foto_profil FROM kepala_bengkel");
		                $qq=mysqli_num_rows($que);
		                $upload_data = $this->upload->data();
		                $file_name = $upload_data['file_name'];
		                $data['foto_profil']=base_url().'user_img/'.$file_name;
		                $usertable= $this->session->userdata('level');
		                $usernamee= array('username_kepala_bengkel' => $username);
		                $jurusann = array('jurusan' => $jurusan);
		                $this->data->update_foto($data,$usertable,$usernamee,$jurusann);
						redirect(base_url('Kepala_bengkel/profile/'.$this->session->userdata('jurusan')));
		        }
			}
			elseif ($URI2 == 'password_updated') {
				$edit = $this->input->post('ganti');
				if (isset($edit)) {
					$username=$this->session->userdata('username');
					$jurusan=$this->session->userdata('jurusan');
					$$l=$this->session->userdata('level');
					$password		= htmlspecialchars($this->input->post('password'));
					$password 		= md5($password);
							
					
					$data  		= array('password' => $password);
					$where 	= array('username_kepala_bengkel' => $username);
					$where2 = array( 'jurusan' => $jurusan);
					$dbtable	= $l;	
					$this->session->set_userdata('password',$password);
					$this->data->update_user($data,$where,$where2,$dbtable);
					redirect('Kepala_bengkel/profile/'.$this->session->userdata('jurusan'));
				}
				else{
					$this->load->view('errir_page');
				}
			}
			else{
				redirect('Kepala_bengkel/profile/'.$this->session->userdata('jurusan'));
			}
		}
	}
	public function dashboard(){
		$l=$this->session->userdata('level');
		if ($l != 'kepala_bengkel') {
			redirect(base_url('auth/login'));
		}
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		$jurusan=$this->session->userdata('jurusan');

		if ($URI != NULL && !$URI2) {
			if ($URI == $jurusan) {
				if ($jurusan) {
					$this->session->set_userdata('URI',$URI);
					$this->load->view('dashboard_kepala_bengkel');
				}
				else{
					$this->load->view('errir_page');
				}
			}
		}
		else{
			if ($this->session->userdata('jurusan') == TRUE) {
				redirect(base_url('kepala_bengkel/dashboard/').$this->session->userdata('jurusan'));
			}
			else{
				redirect(base_url('auth/login'));
			}
		}
	}
	public function data_siswa(){
		$l=$this->session->userdata('level');
		if ($l != 'kepala_bengkel') {
			redirect(base_url('auth/login'));
		}
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		$URI3=$this->uri->segment(5);
		$jurusan=$this->session->userdata('jurusan');
		if ($URI != NULL && $URI2 != NULL && !$URI3) {
			if ($URI == $jurusan) {
				if ($URI2 == 'done') {
					$this->load->view('data_siswa_kepala_bengkel');
				}
				elseif ($URI2 == 'undone') {
					$this->load->view('data_siswa_kepala_bengkel');
				}
				else{
					$this->load->view('errir_page');
				}
			}
			else{
				redirect(base_url('kepala_bengkel/dashboard/').$jurusan);
			}
		}
		else{
			if ($jurusan == TRUE) {
				redirect(base_url('kepala_bengkel/dashboard/').$jurusan);
			}
			else{
				redirect(base_url('auth/login'));
			}
		}
	}
	public function pembimbing(){
		$l=$this->session->userdata('level');
		if ($l != 'kepala_bengkel') {
			redirect(base_url('auth/login'));
		}
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		$jurusan=$this->session->userdata('jurusan');

		if ($URI != NULL && !$URI2) {
			if ($URI == $jurusan) {
				if ($jurusan) {
					$this->session->set_userdata('URI',$URI);
					$this->load->view('data_pembimbing_kepala_bengkel');
				}
				else{
					$this->load->view('errir_page');
				}
			}
			else{
				redirect(base_url('kepala_bengkel/pembimbing/').$jurusan);
			}
		}
		else{
			if ($this->session->userdata('jurusan') == TRUE) {
				redirect(base_url('kepala_bengkel/dashboard/').$this->session->userdata('jurusan'));
			}
			else{
				redirect(base_url('auth/login'));
			}
		}
	}
	public function add_user(){
		$l=$this->session->userdata('level');
		if ($l != 'kepala_bengkel') {
			redirect(base_url('auth/login'));
		}
		include APPPATH.'views/connect.php';
		$URI = $this->uri->segment(3);
		$URI2= $this->uri->segment(4);
		$URI3= $this->uri->segment(5);
		$jurusan=$this->session->userdata('jurusan');

		if ($URI != NULL && $URI2 != NULL && $URI3 == NULL ) {
			if ($URI == $jurusan) {
				if ($URI2 == "siswa") {
					$this->session->set_userdata('add_user',$URI2);
					$this->load->view('add_user');
				}
				elseif ($URI2 == "pembimbing") {
					$this->session->set_userdata('add_user',$URI2);
					$this->load->view('add_user');
				}
				else{
					if ($this->session->userdata('add_user') == TRUE) {
						redirect(base_url('kepala_bengkel/add_user/').$jurusan."/".$this->session->userdata('add_user'));
					}
					else{
						redirect(base_url('kepala_bengkel/pembimbing/').$jurusan);
					}
				}
			}
			else{
				redirect(base_url('kepala_bengkel/pembimbing/').$jurusan);
			}
		}
		elseif ($URI != NULL && $URI2 != NULL && $URI3 != NULL ) {
			$add_user=$this->session->userdata('add_user');
			if ($URI=$jurusan && $URI2 == $add_user) {	
				if ($URI3 == 'edited') {
					$level			= $this->input->post('level');
					$level_required = $this->session->userdata('add_user');
					if ($level == $level_required) {
						$username		= htmlspecialchars($this->input->post('username'));
						$nama_lengkap	= htmlspecialchars($this->input->post('nama_lengkap'));
						$email			= htmlspecialchars($this->input->post('email'));
						$password		= htmlspecialchars($this->input->post('password'));
						$password		= md5($password);
						$jurusan		= htmlspecialchars($this->input->post('jurusan'));
						$username_kabeng= htmlspecialchars($this->session->userdata('username'));
						$data = array(
										'nama_lengkap'	=>	$nama_lengkap,
										'email'			=>	$email,
										'password'		=>	$password,
										'jurusan'		=>	$jurusan,
										'level'			=>	$level
									 );	

						if ($level == 'pembimbing') {
							$sql="SELECT*FROM pembimbing";
							$q=mysqli_query($conn,$sql);
							$datap=mysqli_fetch_assoc($q);
							if ($username != $datap['username_pembimbing']) {
								$dbtable = $level;
								$data2	 = array('username_pembimbing' 		=> $username,
												 'username_kepala_bengkel'	=> $username_kabeng
												);

								$dir_guru=$username;
								$dir=ROOTDIR.'/'.$jurusan.'/'.$dir_guru;
								mkdir($dir);
								$this->data->add_user($dbtable,$data,$data2);
								redirect(base_url('kepala_bengkel/pembimbing/'.$jurusan));
							}
							else{
								?>
								<script type="text/javascript">
									alert('Username Telah Terpakai !');
									document.location.href="<?= base_url('kepala_bengkel/add_user/'.$jurusan.'/'.$add_user) ?>";	
								</script>
								<?php
							}
						}
						elseif ($level == 'siswa') {
							$sql="SELECT*FROM siswa";
							$q=mysqli_query($conn,$sql);
							$datap=mysqli_fetch_assoc($q);
							if ($username != $datap['username']) {
								$username_pembimbing = htmlspecialchars($this->input->post('pembimbing'));
								$kelas   = htmlspecialchars($this->input->post('kelas'));
								$dbtable = $level;
								$data2	 = array('username'	=> $username, 'username_pembimbing'	=> $username_pembimbing, 'kelas' => $kelas );

								$dir_guru=$username_pembimbing;
								$dir_siswa=$username;
								$dir=ROOTDIR.'/'.$jurusan.'/'.$dir_guru.'/'.$dir_siswa;
								var_dump(mkdir($dir));
								$this->data->add_user($dbtable,$data,$data2);
								redirect(base_url('kepala_bengkel/data_siswa/'.$jurusan.'/undone'));
							}
							else{
								?>
								<script type="text/javascript">
									alert('Username Telah Terpakai !');
									document.location.href="<?= base_url('kepala_bengkel/add_user/'.$jurusan.'/'.$add_user) ?>";	
								</script>
								<?php
							}
						}
						else{
							redirect(base_url('kepala_bengkel/dashboard/'.$jurusan));
						}
					}
					else{
						if ($jurusan && $add_user ) {
							redirect(base_url('kepala_bengkel/add_user/'.$jurusan.'/'.$add_user));
						}
						else{
							redirect(base_url('kepala_bengkel/dashboard/'.$jurusan));
						}
					}
				}
				else{
						if ($jurusan && $add_user ) {
							redirect(base_url('kepala_bengkel/add_user/'.$jurusan.'/'.$add_user));
						}
						else{
							redirect(base_url('kepala_bengkel/dashboard/'.$jurusan));
						}
				}
			}
			else{	
				if ($jurusan && $add_user ) {
					redirect(base_url('kepala_bengkel/add_user/'.$jurusan.'/'.$add_user));
				}
				else{
					redirect(base_url('kepala_bengkel/dashboard/'.$jurusan));
				}
			}
		}
		else{	
			if ($this->session->userdata('jurusan') == TRUE) {
				redirect(base_url('kepala_bengkel/dashboard/').$this->session->userdata('jurusan'));
			}
			else{
				redirect(base_url('auth/login'));
			}
		}
	}
	public function assignment(){
		$jurusan=$this->session->userdata('jurusan');
		include APPPATH.'views/connect.php';
		$URI =$this->uri->segment(3);
		$URI2 =$this->uri->segment(4);
		$username=$this->uri->segment(4);
		$username_siswa=$this->uri->segment(5);
		$URI3 =$this->uri->segment(5);
		$w="SELECT*FROM kepala_bengkel WHERE jurusan='$jurusan'";
		$ww=mysqli_query($conn,$w);
		$www=mysqli_fetch_assoc($ww);
		$wwe=mysqli_num_rows($ww);

		$q="SELECT*FROM pembimbing WHERE username_pembimbing='$username'";
		$qq=mysqli_query($conn,$q);
		$qqq=mysqli_fetch_assoc($qq);
		$qqe=mysqli_num_rows($qq);

		$e="SELECT*FROM siswa WHERE username_pembimbing='$username'";
		$ee=mysqli_query($conn,$e);
		$eee=mysqli_fetch_assoc($ee);
		if ($this->session->userdata('level') != 'kepala_bengkel') {
			redirect(base_url('auth/login'));
		}
		elseif ($URI == $jurusan) {
			if ($URI == $jurusan && !$URI2 && !$URI3 ) {
				$this->load->view('assignment');
			}
			elseif ($URI == $jurusan && $URI2 == TRUE && !$URI3) {
				if ($qqq != NULL || $qqe > 0) {
					if ($qqq['username_pembimbing'] == $username) {
						$this->load->view('assignment_2');
					}
				}	
				else{
					redirect(base_url('Kepala_bengkel/assignment/'.$jurusan));
				}
			}
			elseif ($URI == $jurusan && $URI2 == TRUE &&  $URI3 == TRUE) {
					$this->load->view('assignment_3');
			}
			else{
				echo "gaada uri";
			}
		}
		else{
			redirect(base_url('Kepala_bengkel/assignment/'.$jurusan));	
		}
	}
	public function siswa()
	{
		include APPPATH.'views/connect.php';
		$l=$this->session->userdata('level');
		if ($l != 'kepala_bengkel') {
			redirect(base_url('auth/login'));
		}
		else{
			$jurusan=$this->session->userdata('jurusan');
			$URI2=$this->uri->segment(2);
			$URI3=$this->uri->segment(3);
			$URI4=$this->uri->segment(4);
			$URI5=$this->uri->segment(5);
			$URI6=$this->uri->segment(6);
			if ($URI2 == TRUE && $URI3== TRUE  && $URI4== TRUE  && $URI5== TRUE  && $URI6== TRUE ) {
				if ($URI2 == 'siswa') {
					if ($URI3 == $jurusan) {
						$q="SELECT*FROM siswa WHERE jurusan='$jurusan' AND username='$URI6' ";
						$qq=mysqli_query($conn,$q);
						$qnr=mysqli_num_rows($qq);
						if ($URI4 == 'deleted') {
							if ($qnr  > 0) {
								$username_pembimbing=$this->uri->segment(5);
								$user=htmlspecialchars($URI6);
								$data=array('username' => $user);
								$dbtable = 'siswa';

								$dir_guru=$username_pembimbing;
								$jurusan = $this->session->userdata('jurusan');
								$dir=ROOTDIR.'/'.$jurusan.'/'.$dir_guru;
								if (file_exists($dir.'/'.$user)) {
						            $p=scandir($dir);
						            $c=count($p);
						            $no=1;
						           	$noo=1;
									for ($d=2; $d <$c ; $d++) {
										$no++;
								            $sc=scandir($dir.'/'.$p[$no]);
								           	$s=count($sc);
								           	for ($i=2; $i <$s ; $i++) {
						           			$noo++; 
								           	unlink($dir.'/'.$user.'/'.$sc[$noo]);
								           	if (!file_exists($dir.'/'.$user.'/')) {
						        				rmdir($dir.'/'.$URI6);
								           	}
											$this->data->userdel($data,$dbtable);
											//redirect(base_url('kepala_bengkel/data_siswa/'.$jurusan.'/undone'));
								           	}
					            	}
								}
					        			rmdir($dir.'/'.$URI6);
										$this->data->userdel($data,$dbtable);
										redirect(base_url('kepala_bengkel/data_siswa/'.$jurusan.'/undone'));
							}
							else{
								echo "gaada";
							}
						}
						if ($URI4 == 'updated') {
							if ($qnr  > 0) {
								$username_pembimbing=$this->uri->segment(5);
								$user=htmlspecialchars($URI6);
								$user_p=$this->input->post('username_pembimbing');
								$status=array('status_assignment' => 'waiting');
								$data=array('username_pembimbing' => $user_p);
								$where=array('username' => $user);
								$dbtable = 'siswa';

								$dir_guru=$username_pembimbing;
								$jurusan = $this->session->userdata('jurusan');
								$dir=ROOTDIR.'/'.$jurusan.'/'.$dir_guru;
						            $p=scandir($dir);
						            $c=count($p);
						            $no=1;
						           	$noo=1;
						           	$kosong= NULL;
								if (file_exists($dir.'/'.$user)) {
							        $sc=scandir($dir.'/'.$user);
							        $s=count($sc);
									$ps="UPDATE assignment SET laporan='$kosong', absensi='$kosong', agenda='$kosong', nilai='$kosong', sertifikat='$kosong' WHERE username='$user'";
									$pss=mysqli_query($conn,$ps);
									for ($d=2; $d <$c ; $d++) {
										$no++;
							           	for ($i=2; $i <$s ; $i++) {
					           				$noo++;
							           		unlink($dir.'/'.$user.'/'.$sc[$noo]);
							           	}
					        			rmdir($dir.'/'.$URI6);
					            	}
								}
										var_dump($dir.'/'.$user);
										$newdir=ROOTDIR.'/'.$jurusan.'/'.$user_p;
										$this->data->useradd($data,$where,$dbtable,$newdir,$user,$status);
										redirect(base_url('kepala_bengkel/data_siswa/'.$jurusan.'/undone'));
							}
							else{
								echo "gaada";
							}
						}
					}
				}
				else{
					redirect(base_url('auth/login'));
				}
			}
		}
	}
	public function info(){
		include APPPATH.'views/connect.php';
		$l=$this->session->userdata('level');
		if ($l != 'kepala_bengkel') {
			redirect(base_url('auth/login'));
		}
		$jurusan=$this->session->userdata('jurusan');
		$URI=$this->uri->segment(3);
		if ($URI == $jurusan) {
			$this->load->view('info_siswa');	

		}
		else{
			$this->load->view('errir_page');
		}
	}
}