	<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pembimbing extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
	}
	public function index(){
		$l=$this->session->userdata('level');
		if ($l != 'pembimbing') {
			redirect(base_url('auth/login'));
		}
		$URI=$this->uri->segment(3);
		if (!$URI) {
			redirect('auth');
		}
		else{ 
			$this->load->view('errir_page');
		}
	}
	public function dashboard(){
		$l=$this->session->userdata('level');
		if ($l != 'pembimbing') {
			redirect(base_url('auth/login'));
		}
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		$jurusan=$this->session->userdata('jurusan');

		if ($URI != NULL && !$URI2) {
			if ($URI == $jurusan) {
				if ($jurusan) {
					$this->session->set_userdata('URI',$URI);
					$this->load->view('dashboard_pembimbing');
				}
				else{
					$this->load->view('errir_page');
				}
			}
			else{
				redirect(base_url('pembimbing/dashboard/').$jurusan);
			}
		}
		else{
			if ($this->session->userdata('jurusan') == TRUE) {
				redirect(base_url('pembimbing/dashboard/').$this->session->userdata('jurusan'));
			}
			else{
				redirect(base_url('auth/login'));
			}
		}
	}
	public function profile(){
		$l=$this->session->userdata('level');
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		if ($l == 'pembimbing' && $URI == $this->session->userdata('jurusan') && !$URI2) {
			$this->load->view('pembimbing_profile');
		}
		elseif ($l != 'pembimbing') {
			redirect(base_url('auth/login'));
		}
		if ($URI == TRUE && $URI2 ==TRUE) {
			if ($URI2 == 'updated') {
				$edit = $this->input->post('ganti');
				if (isset($edit)) {
					$username=$this->session->userdata('username');
					$jurusan=$this->session->userdata('jurusan');
					$$l=$this->session->userdata('level');
					$nama_lengkap		= htmlspecialchars($this->input->post('nama_lengkap'));
					$email				= htmlspecialchars($this->input->post('email'));
					$telepon			= htmlspecialchars($this->input->post('telepon'));
							
					
					$data  		= array(
										 'nama_lengkap' => $nama_lengkap, 
										 'email'		=> $email,
										 'telepon'		=> $telepon
										);
					$where 	= array('username_pembimbing' => $username);
					$where2 = array( 'jurusan' => $jurusan);
					$dbtable	= $l;	
					$this->data->update_user($data,$where,$where2,$dbtable);
					redirect(base_url('pembimbing/profile/'.$this->session->userdata('jurusan')));
				}
				else{
					$this->load->view('errir_page');
				}
			}
			elseif ( $URI2 == 'foto_updated') {
				include APPPATH.'views/connect.php';
				$username=$this->session->userdata('username');
				$jurusan=$this->session->userdata('jurusan');

		        $config['upload_path']          = './user_img/';
		        $config['allowed_types']        = 'gif|jpg|png|jpeg';
		        $config['max_size']             = 5000;
		        $config['file_name']            = 'IMG_'.date('Ymd-His').'_'.$username;

		        $this->load->library('upload', $config);

		        if ( ! $this->upload->do_upload('foto'))
		        {
		                redirect(base_url('pembimbing/profile/'.$jurusan));
		        }
		        else
		        {
		                $que=mysqli_query($conn,"SELECT foto_profil FROM pembimbing WHERE jurusan='$jurusan' AND username_pembimbing='$username'");
		                $qq=mysqli_num_rows($que);
		                $upload_data = $this->upload->data();
		                $file_name = $upload_data['file_name'];
		                $data['foto_profil']=base_url().'user_img/'.$file_name;
		                $usertable= $this->session->userdata('level');
		                $usernamee= array('username_pembimbing' => $username);
		                $jurusann = array('jurusan' => $jurusan);
		                $this->data->update_foto($data,$usertable,$usernamee,$jurusann);
						redirect(base_url('pembimbing/profile/'.$this->session->userdata('jurusan')));
		        }
			}
			elseif ($URI2 == 'password_updated') {
				$edit = $this->input->post('ganti');
				if (isset($edit)) {
					$username=$this->session->userdata('username');
					$jurusan=$this->session->userdata('jurusan');
					$$l=$this->session->userdata('level');
					$password		= $this->input->post('password');
					$password 		= md5($password);
							
					
					$data  		= array('password' => $password);
					$where 	= array('username_pembimbing' => $username);
					$where2 = array( 'jurusan' => $jurusan);
					$dbtable	= $l;	
					$this->session->set_userdata('password',$password);
					$this->data->update_user($data,$where,$where2,$dbtable);
					redirect(base_url('pembimbing/profile/'.$this->session->userdata('jurusan')));
				}
				else{
					$this->load->view('errir_page');
				}
			}
			else{
				redirect('pembimbing/profile/'.$this->session->userdata('jurusan'));
			}
		}
	}
	public function siswa(){
		$URI=$this->uri->segment(3);
		$jurusan=$this->session->userdata('jurusan');
		$level=$this->session->userdata('level');
		if ($URI == $jurusan AND $level == 'pembimbing') {
			$this->load->view('data_siswa_pembimbing');
		}
		else{
			redirect(base_url('auth'));
		}
	}
	public function denying(){
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		$URI3=$this->uri->segment(5);
		$jurusan=$this->session->userdata('jurusan');
		$level=$this->session->userdata('level');
		if ($URI == $jurusan AND $level == 'pembimbing' AND $URI2 != NULL AND $URI3 != NULL) {
			$username = array('username' => $URI2);
			$id_assignment = array('id_assignment' => $URI3);
			$status = array('status_assignment' => 'waiting');
			$dbtable = 'assignment';

			$this->data->set_status_assignment($username,$dbtable,$id_assignment,$status);
			redirect(base_url('pembimbing/siswa/'.$jurusan.'/accepted'));
		}	
		else{
			redirect(base_url('auth'));
		}
	}
	public function accepting(){
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		$URI3=$this->uri->segment(5);
		$jurusan=$this->session->userdata('jurusan');
		$level=$this->session->userdata('level');
		if ($URI == $jurusan AND $level == 'pembimbing' AND $URI2 != NULL AND $URI3 != NULL) {
			$username = array('username' => $URI2);
			$id_assignment = array('id_assignment' => $URI3);
			$status = array('status_assignment' => 'accepted');
			$dbtable = 'assignment';

			$this->data->set_status_assignment($username,$dbtable,$id_assignment,$status);
			redirect(base_url('pembimbing/dashboard/'.$jurusan));
		}	
		else{
			redirect(base_url('auth'));
		}
	}
	public function assignment(){
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		$URI3=$this->uri->segment(5);
		$jurusan=$this->session->userdata('jurusan');
		$username=$this->session->userdata('username');
		if ($URI == $jurusan AND $URI2 == $username AND $URI3 == NULL) {
			$this->load->view('assignment_pembimbing');
		}
		elseif ($URI == $jurusan AND $URI2 == $username AND $URI3 == TRUE) {
			$this->load->view('assignment_pembimbing_3');

		}
		else{
			redirect(base_url('pembimbing/assignment/'.$jurusan.'/'.$username));
		}
	} 
	public function info(){
		include APPPATH.'views/connect.php';
		$l=$this->session->userdata('level');
		if ($l != 'pembimbing') {
			redirect(base_url('auth/login'));
		}
		$jurusan=$this->session->userdata('jurusan');
		$URI=$this->uri->segment(3);
		if ($URI == $jurusan) {
			$this->load->view('info_siswa');	
			
		}
		else{
			$this->load->view('errir_page');
		}
	}
}