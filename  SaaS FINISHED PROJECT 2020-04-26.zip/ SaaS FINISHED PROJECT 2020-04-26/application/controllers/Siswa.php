	<?php
defined('BASEPATH') OR exit('No direct script access allowed');
define('ROOTDIR', 'C:/xampp/htdocs/assignment');
class Siswa extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->library('session');	
		include APPPATH.'views/connect.php';
		$username=$this->session->userdata('username');
		$password=$this->session->userdata('password');
		$sql1="SELECT*FROM siswa WHERE username='$username' AND password='$password'";
		$q1=mysqli_query($conn,$sql1);
		$data=mysqli_fetch_assoc($q1);
		if ($this->session->userdata('level') == "kepala_bengkel") {
			redirect(base_url('kepala_bengkel/dashboard/').$this->session->userdata('jurusan'));
		}
		elseif ($this->session->userdata('level') == "pembimbing") {
			redirect(base_url('pembimbing/dashboard/').$this->session->userdata('jurusan'));
		}
		elseif (!$data['tempat_pkl'] || !$data['start_pkl'] || !$data['finish_pkl'] || !$data['pembimbing_perusahaan'] ) {
			redirect(base_url('auth/before'));
		}
	}
	public function index(){
		redirect(base_url('auth/login'));
		//
	}
	public function home(){
		$jurusan=$this->session->userdata('jurusan');
		if ($this->uri->segment(3) != $jurusan) {
			redirect(base_url('siswa/home/'.$jurusan));	
		}
		$this->load->view('home_siswa');
	}
	public function profile(){
		$l=$this->session->userdata('level');
		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		if ($l == 'siswa' && $URI == $this->session->userdata('jurusan') && !$URI2) {
			$this->load->view('profile_siswa');
		}
		elseif ($URI != $this->session->userdata('jurusan')) {
			redirect('siswa/profile/'.$this->session->userdata('jurusan'));
		}
		if ($URI == TRUE && $URI2 ==TRUE) {
			if ($URI2 == 'updated') {
				$edit = $this->input->post('ganti');
				if (isset($edit)) {
					$username=$this->session->userdata('username');
					$jurusan=$this->session->userdata('jurusan');
					$l=$this->session->userdata('level');

					$nama_lengkap		= htmlspecialchars($this->input->post('nama_lengkap'));
					$email				= htmlspecialchars($this->input->post('email'));
					$telepon			= htmlspecialchars($this->input->post('telepon'));
							
					
					$data  		= array(
										 'nama_lengkap' => $nama_lengkap, 
										 'email'		=> $email,
										 'telepon'		=> $telepon
										);

					$where 	= array('username' => $username);
					$where2 = array( 'jurusan' => $jurusan);
					$dbtable	= $l;	

					$this->data->update_user($data,$where,$where2,$dbtable);
					redirect(base_url('siswa/profile/'.$this->session->userdata('jurusan')));
				}
				else{
					$this->load->view('errir_page');
				}
			}
			elseif ( $URI2 == 'foto_updated') {
				echo "foto_updated";
				include APPPATH.'views/connect.php';
				$username=$this->session->userdata('username');
				$jurusan=$this->session->userdata('jurusan');

		        $config['upload_path']          = './user_img/';
		        $config['allowed_types']        = 'gif|jpg|png|jpeg';
		        $config['max_size']             = 5000;
		        $config['file_name']            = 'IMG_'.date('Ymd-His').'_'.$username;

		        $this->load->library('upload', $config);

		        if ( ! $this->upload->do_upload('foto'))
		        {
		                redirect(base_url('Kepala_bengkel/profile/'.$jurusan));
		        }
		        else
		        {
		                $que=mysqli_query($conn,"SELECT foto_profil FROM kepala_bengkel");
		                $qq=mysqli_num_rows($que);
		                $upload_data = $this->upload->data();
		                $file_name = $upload_data['file_name'];
		                $data['foto_profil']=base_url().'user_img/'.$file_name;
		                $usertable= $this->session->userdata('level');
		                $usernamee= array('username' => $username);
		                $jurusann = array('jurusan' => $jurusan);
		                $this->data->update_foto($data,$usertable,$usernamee,$jurusann);
						redirect(base_url('siswa/profile/'.$this->session->userdata('jurusan')));
		        }
			}
			elseif ($URI2 == 'password_updated') {
				$edit = $this->input->post('ganti');
				if (isset($edit)) {
					$username=$this->session->userdata('username');
					$jurusan=$this->session->userdata('jurusan');
					$$l=$this->session->userdata('level');
					$password		= htmlspecialchars($this->input->post('password'));
					$password 		= md5($password);
							
					
					$data  		= array('password' => $password);
					$where 	= array('username' => $username);
					$where2 = array( 'jurusan' => $jurusan);
					$dbtable	= $l;	

					$this->session->set_userdata('password',$password);
					$this->data->update_user($data,$where,$where2,$dbtable);
					redirect('siswa/profile/'.$this->session->userdata('jurusan'));
				}
				else{
					$this->load->view('errir_page');
				}
			}
			else{
				redirect('siswa/profile/'.$this->session->userdata('jurusan'));
			}
		}
	}
	public function add(){
		include APPPATH.'views/connect.php';
		$level=$this->session->userdata('level');
		$username=$this->session->userdata('username');
		$jurusan=$this->session->userdata('jurusan');

		date_default_timezone_set('Asia/Jakarta');
		$datenow=date('Y-m-d');

		$p="SELECT*FROM assignment WHERE username='$username' AND deadline_pengumpulan >'$datenow'";
		$pp=mysqli_query($conn,$p);
		$ppp=mysqli_fetch_array($pp);

		$URI=$this->uri->segment(3);
		$URI2=$this->uri->segment(4);
		
		if ($URI == $jurusan AND $ppp > 0) {
			if ($URI2 == 'laporan') {
				$this->session->set_userdata('jenis','laporan');
				$this->load->view('add_assignment');
			}
			elseif($URI2 == 'absensi') {;
				$this->session->set_userdata('jenis','absensi');
				$this->load->view('add_assignment');
			}
			elseif($URI2 == 'agenda') {;
				$this->session->set_userdata('jenis','agenda');
				$this->load->view('add_assignment');
			}
			elseif($URI2 == 'nilai') {;
				$this->session->set_userdata('jenis','nilai');
				$this->load->view('add_assignment');
			}
			elseif($URI2 == 'sertifikat') {;
				$this->session->set_userdata('jenis','sertifikat');
				$this->load->view('add_assignment');
			}
			else{
				redirect(base_url('siswa/home/'.$jurusan));
			}
		}		
		else{
			redirect(base_url('siswa/home/'.$jurusan));
		}
	}
	public function proccess(){
		include APPPATH.'views/connect.php';
		$jurusan=$this->session->userdata('jurusan');
		$jenis=$this->session->userdata('jenis');
		$level=$this->session->userdata('level');
		$jenis=$this->session->userdata('jenis');
		$username=$this->session->userdata('username');
		$kirim=$this->input->post('kirim');
		$URI=$this->uri->segment(3);

		$p="SELECT*FROM siswa WHERE jurusan='$jurusan' AND username='$username'";
		$pp=mysqli_query($conn,$p);
		$ppp=mysqli_fetch_assoc($pp);
		$username_guru=$ppp['username_pembimbing'];
		$nama_lengkap=$ppp['nama_lengkap'];

		if ($URI == $jurusan && isset($kirim) && $level = 'siswa') {


	        $tmp=$_FILES['file_laporan']['tmp_name'];
	        
	        $nama_file=$jenis.'.'.$nama_lengkap.'-'.date('Y-m-d').'-'.$_FILES['file_laporan']['name'];

	        $lokasi	  =ROOTDIR.'/'.$jurusan.'/'.$username_guru.'/'.$username.'/'.$nama_file;

	        move_uploaded_file($tmp, $lokasi);


	        $usertable= 'assignment';
	        $data 	  = array($jenis	=> $nama_file);
	        $usernamee= array('username' => $username);

	        $this->data->upload_assignment($data,$usertable,$usernamee);

			redirect(base_url('siswa/home/'.$this->session->userdata('jurusan')));
		}
	}
}