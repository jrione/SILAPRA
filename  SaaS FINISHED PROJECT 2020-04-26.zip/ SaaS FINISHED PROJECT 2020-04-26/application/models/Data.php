<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
	}
	public function add_user($dbtable,$data,$data2){
		if ($dbtable == "pembimbing") {
			$this->db->set("username_pembimbing",$data2['username_pembimbing']);
			$this->db->set("username_kepala_bengkel",$data2['username_kepala_bengkel']);
			$this->db->insert($dbtable,$data);
		}
		else{
			$this->db->set("username",$data2['username']);
			$this->db->set("username_pembimbing",$data2['username_pembimbing']);
			$this->db->set("kelas",$data2['kelas']);
			$this->db->insert($dbtable,$data);
			$user_fk=array('username'=>$data2['username']);
			$this->db->insert('assignment',$user_fk);
		}
	}
	public function update_foto($data,$usertable,$usernamee,$jurusann){
		$this->db->where($usernamee);
		$this->db->where($jurusann);
		$this->db->update($usertable,$data);
	}
	public function update_user($data,$where,$where2,$dbtable){
		$this->db->where($where);
		$this->db->where($where2);
		$this->db->update($dbtable,$data);
	}
	public function update_password($data,$where,$where2,$dbtable){
		$this->db->where($where);
		$this->db->where($where2);
		$this->db->update($dbtable,$data);
	}
	public function userdel($data,$dbtable){
		$this->db->where($data);
		$this->db->delete($dbtable);
	}
	public function useradd($data,$where,$dbtable,$newdir,$user,$status){
		$this->db->where($where);
		$this->db->update($dbtable,$data);
		$this->db->where($where);
		$this->db->update('assignment',$status);
		mkdir($newdir.'/'.$user);
	}
	public function set_status_assignment($username,$dbtable,$id_assigment,$status){
		$this->db->where($username);
		$this->db->where($id_assigment);
		$this->db->update($dbtable,$status);
	}
	public function update_deadline_assignment($assignment,$deadlinennya,$wheresiswa){
		$this->db->where($wheresiswa);
		$this->db->update($assignment,$deadlinennya);
	}
	public function update_from_user($datasiswa,$dbsiswa,$wheresiswa,$wherejursan){
		$this->db->where($wheresiswa);
		$this->db->where($wherejursan);
		$this->db->update($dbsiswa,$datasiswa);
	}
	public function upload_assignment($data,$usertable,$usernamee){
		$this->db->where($usernamee);
		$this->db->update($usertable,$data);
	}
}