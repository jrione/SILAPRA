<?php
$jurusan=$this->session->userdata('jurusan');
$datenow=date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<title>Dashboard | Bengkel</title>
    <?php  $this->load->view('sb_head') ?>

<body id="page-top">
  <div id="wrapper">
    <?php $this->load->view('sb_sidebar') ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php  $this->load->view('sb_topbar') ?>
        <div class="container-fluid">

          <div class="d-sm-flex align-items-center justify-content-between mb-4">
          </div>
          <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Upload Laporan</h6>
                </div>
                <div class="card-body">
            <div class="table-responsive">
              <form method="POST" enctype="multipart/form-data" action="<?= base_url('siswa/proccess/'.$jurusan) ?>">
                  <input type="file" class="btn" style="float: center" name="file_laporan" required="">
                  <input type="submit" class="btn form-control bg-info text-white" value="Kirim" name="kirim" onclick="return confirm('Anda Yakin akan Mengirim file ini ?')">
              </form>
            </div>
          </div>
        </div>
        <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Catatan :</h6>
                </div>
                <div class="card-body">
            <div class="table-responsive">
              <p class="text-info"> Masukkan file yang benar, jangan mengirim file yang aneh-aneh. Upload file yang berekstensi .DOC, .DOCX ataupun .PDF . Jika ketahuan ada yang mengirim file yang tidak semestinya, akan Ada konsekuensinya.</p>
              <p></p>
            </div>
          </div>
        </div>
        </div>
        </div>
       <?php $this->load->view('sb_footer') ?>

      </div>

      
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->

  <!-- Bootstrap core JavaScript-->
  <?php $this->load->view('sb_include_js') ?>
  <!-- Script JS-->

  <?php $this->load->view('sb_modal') ?>
    </div>
  </div>
</body>

</html>
