<?php
include APPPATH.'views/connect.php';
$jurusan = $this->session->userdata('jurusan');
$level_required = $this->session->userdata('add_user');
?>
<!DOCTYPE html>
<html lang="en">
<title>Tambah Siswa | Bengkel</title>
    <?php  $this->load->view('sb_head') ?>
<body id="page-top">
  <div id="wrapper">
    <?php $this->load->view('sb_sidebar') ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php  $this->load->view('sb_topbar') ?>
        <div class="container-fluid">

          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800 ">Tambah Data <?php if ($this->uri->segment(4) == "siswa") { echo "Siswa"; } else{echo "Pembiming";} ?></h1>
           <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>-->
          </div>
              <div class="row">
                <div class="col-sm-1  "></div>
                <div class="col-sm-10">
                  <div class="card shadow mb-4">
                    <div class="card-body">
                        <form class="form-horizontal" action="<?= base_url('kepala_bengkel/add_user/'.$jurusan.'/'.$level_required.'/edited')  ?>" method="POST">
                          <div class="form-group">
                              <label class="control-label col-xs-3" for="username">Username</label>
                              <div class="col-xs-9">
                                  <input type="text" class="form-control" id="username" name="username" required="">
                              </div>
                          </div>
                          <div class="form-group">
                              <label class="control-label col-xs-3" for="namalengkap">Nama Lengkap</label>
                              <div class="col-xs-9">
                                  <input type="text" class="form-control" id="namalengkap" name="nama_lengkap" required="">
                              </div>
                          </div>
                          <?php
                          if ($level_required == 'pembimbing') {
                          ?>
                          <div class="form-group">
                              <label class="control-label col-xs-3" for="email">Email</label>
                              <div class="col-xs-9">
                                  <input type="email" class="form-control" id="email" name="email">
                              </div>
                          </div>
                          <?php
                          }
                          else{
                            $q="SELECT*FROM pembimbing WHERE jurusan='$jurusan'";
                            $qq=mysqli_query($conn,$q);
                            ?>
                              <div class="form-group">
                                  <label class="control-label col-xs-3" for="pembimbing">Guru Pembimbing</label>
                                  <div class="col-xs-9">
                                    <select class="form-control" name="pembimbing" required="">
                                      <?php while ($qqq=mysqli_fetch_array($qq) ){ ?>
                                      <option value="<?= $qqq['username_pembimbing'] ?>"><?= $qqq['nama_lengkap'] ?></option>
                                      <?php }?>
                                    </select>
                                  </div>
                              </div>
                              <div class="form-group">
                                  <label class="control-label col-xs-3" for="pembimbing">Kelas</label>
                                  <div class="col-xs-9">
                                    <select class="form-control" name="kelas" required="">
                                      <option value="A">A</option>
                                      <option value="B">B</option>
                                    </select>
                                  </div>
                              </div>
                            <?php
                              }
                              ?>
                          <div class="form-group">
                              <label class="control-label col-xs-3" for="password">Password</label>
                              <div class="col-xs-9">
                                  <input type="password" class="form-control" id="password" name="password" required="">
                              </div>
                          </div>
                          <div class="form-group">
                                  <input type="hidden" name="jurusan" value="<?= $this->session->userdata('jurusan') ?>">
                                  <input type="hidden" name="level" value="<?=  $this->uri->segment(4) ?>">
                                  <button type="submit" class="btn btn-primary" name="edit">
                                    <i class="fa fa-plus"></i> Tambahkan
                                  </button>
                          </div>
                        </form>
                    </div>
                  </div>
                </div>
                <div class="col-sm-2"></div>
              </div>
        </div>
      </div>

    <?php $this->load->view('sb_footer') ?>
      
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <?php $this->load->view('sb_modal') ?>

  <!-- Bootstrap core JavaScript-->
  <?php $this->load->view('sb_include_js') ?>
  <!-- Script JS-->

    </div>
  </div>
</body>

</html>
