<?php
    $jurusan=$this->session->userdata('jurusan');
    if ($jurusan == 'Kepala_bengkel') {
      redirect(base_url('auth/login'));
    }
include APPPATH.'views/connect.php';
$username=$this->session->userdata('username');
$jurusan=$this->session->userdata('jurusan');
$qe="SELECT*FROM pembimbing p RIGHT OUTER JOIN siswa s USING(username_pembimbing) LEFT OUTER JOIN assignment a USING(username) WHERE s.jurusan='$jurusan' AND p.jurusan='$jurusan'";
$qqe=mysqli_query($conn,$qe);
$qqne=mysqli_num_rows($qqe);
$qqqe=mysqli_fetch_assoc($qqe);
$root_path=ROOTDIR;
$guru_path=$qqqe['username_pembimbing'];
$total_path=$root_path.'/'.$jurusan.'/';
$p=scandir($total_path);
$c=count($p);
$no=1; 
?>
<!DOCTYPE html>
<html lang="en">
<title>Direktori | Bengkel</title>
    <?php  $this->load->view('sb_head') ?>

<body id="page-top">
  <div id="wrapper">
    <?php $this->load->view('sb_sidebar') ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php  $this->load->view('sb_topbar') ?>
        <div class="container-fluid">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800 ">Direktori</h1>
          </div>
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary"><a style="text-decoration: none" href="<?= base_url('kepala_bengkel/assignment/'.$jurusan)?>"><i class="fa fa-folder-open rounded-circle"></i>Assignment </a></h6>
            </div>
            <div class="card-body">
                <table>
                  <?php
                  for ($i=2; $i <$c ; $i++) {
                    $no++; 
                  ?>
                  <tr>
                    <td><h4><div class="badge"><i class="fa fa-folder rounded-circle"></i>  <a target="" href="<?= base_url('kepala_bengkel/assignment/'.$jurusan.'/'.$p[$no]) ?>" style="text-decoration: none" ><?= $p[$no] ?></a></h4></td>
                  </tr>
                  <?php
                  }
                  ?>
                </table>
            </div>
          </div>

        </div>

      </div>

    <?php $this->load->view('sb_footer') ?>
      
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->

  <!-- Bootstrap core JavaScript-->
  <?php $this->load->view('sb_include_js') ?>
  <!-- Script JS-->

  <?php $this->load->view('sb_modal') ?>
    </div>
  </div>
</body>

</html>
