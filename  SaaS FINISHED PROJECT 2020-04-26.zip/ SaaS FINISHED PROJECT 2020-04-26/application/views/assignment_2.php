<?php
include APPPATH.'views/connect.php';
$username=$this->session->userdata('username');
$jurusan=$this->session->userdata('jurusan');
$uri=$this->uri->segment(4);
$qe="SELECT*FROM pembimbing p RIGHT OUTER JOIN siswa s USING(username_pembimbing) LEFT OUTER JOIN assignment a USING(username) WHERE s.jurusan='$jurusan' AND p.username_pembimbing ='$uri'";
$qqe=mysqli_query($conn,$qe);
$qqne=mysqli_num_rows($qqe);
$qqqe=mysqli_fetch_assoc($qqe);
$s="SELECT*FROM pembimbing WHERE jurusan='$jurusan' AND username_pembimbing='$uri'";
$ss=mysqli_query($conn,$s);
$sss=mysqli_fetch_assoc($ss);
$total_path=ROOTDIR.'/'.$jurusan.'/'.$qqqe['username_pembimbing'];
  $p=scandir($total_path);
  $c=count($p);
  $no=1; 
$se="SELECT  
a.id_assignment,
a.username,
a.absensi,
a.laporan,
a.agenda,
a.nilai,
a.sertifikat,
a.deadline_pengumpulan,
a.status_assignment FROM siswa s RIGHT OUTER JOIN assignment a USING(username) WHERE s.jurusan='$jurusan' ";
$sse=mysqli_query($conn,$se);
$ssse=mysqli_fetch_assoc($sse);
$root_path=ROOTDIR;
?>
<!DOCTYPE html>
<html lang="en">
<title>Direktori | Bengkel</title>
    <?php  $this->load->view('sb_head') ?>

<body id="page-top">
  <div id="wrapper">
    <?php $this->load->view('sb_sidebar') ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php  $this->load->view('sb_topbar') ?>
        <div class="container-fluid">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800 ">Direktori </h1>
          </div>
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary"><a style="text-decoration: none" href="<?= base_url('kepala_bengkel/assignment/'.$jurusan)?>"><i class="fa fa-folder-open rounded-circle"></i>Assignment </a> <i class="fa fa-arrow-right rounded-circle"></i><a style="text-decoration: none" href="<?= base_url('kepala_bengkel/assignment/'.$jurusan.'/'.$this->uri->segment(4))?>"> <?= $this->uri->segment(4) ?></a></h6>
            </div>
            <div class="card-body">
                <table>
                  <?php
              if ($qqqe != NULL) {
                if ( $uri == $sss['username_pembimbing']) {
                  if (file_exists($total_path)) {
                    for ($i=2; $i <$c ; $i++) {
                      $no++; 
                      ?>
                  <tr>
                    <td><h4><div class="badge"><i class="fa fa-folder rounded-circle"></i>  <a href="<?= base_url('kepala_bengkel/assignment/'.$jurusan.'/'.$uri.'/'.$p[$no]) ?>" style="text-decoration: none"><?= $p[$no] ?></a></h4></td>
                  </tr>
                  <?php
                    }
                  }
                  else{
                    echo "<h5 class='badge badge-info'>Tidak Ada Direktori</h5>";
                  } 
              }
              else{
                echo "<h5 class='badge badge-info'>Tidak Ada Direktori</h5>";
              }
             } 
             else{
                echo "<h5 class='badge badge-info'>Tidak Ada Direktori</h5>";
              }
                 ?>
                </table>
            </div>
          </div>

        </div>

      </div>

    <?php $this->load->view('sb_footer') ?>
      
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->

  <!-- Bootstrap core JavaScript-->
  <?php $this->load->view('sb_include_js') ?>
  <!-- Script JS-->

  <?php $this->load->view('sb_modal') ?>
    </div>
  </div>
</body>

</html>