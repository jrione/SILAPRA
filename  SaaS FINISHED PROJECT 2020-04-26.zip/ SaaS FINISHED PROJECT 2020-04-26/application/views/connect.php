<?php
		$conn=mysqli_connect('localhost','c5pajri','c5pajriii','c5p');
?>
