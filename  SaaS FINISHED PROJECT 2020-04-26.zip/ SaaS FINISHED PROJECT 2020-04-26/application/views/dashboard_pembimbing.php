<!DOCTYPE html>
<html lang="en">
<title>Dashboard | Guru</title>
    <?php  $this->load->view('sb_head') ?>

<body id="page-top">
  <div id="wrapper">
    <?php $this->load->view('sb_sidebar') ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php  $this->load->view('sb_topbar') ?>
        <div class="container-fluid">

          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800 ">Dashboard</h1>
           <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>-->
          </div>
          <?php $this->load->view('sb_content_row'); ?>
           <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Mengunggu Persetujuan</h6>
                </div>
                <div class="card-body">
            <div class="table-responsive text-center">
                  <?php
                  $datenow=date('Y-m-d');
                  include APPPATH.'views/connect.php';
                  $jurusan=$this->session->userdata('jurusan');
                  $username=$this->session->userdata('username');
                  $q="SELECT a.id_assignment,a.username,a.absensi,a.laporan,a.agenda,a.nilai,a.sertifikat,a.deadline_pengumpulan,a.status_assignment,s.nama_lengkap,s.username_pembimbing,s.kelas FROM siswa s RIGHT OUTER JOIN assignment a USING(username) WHERE s.jurusan='$jurusan' AND a.status_assignment='waiting' AND a.deadline_pengumpulan > '$datenow' AND s.username_pembimbing='$username' ORDER BY s.nama_lengkap ASC";
                  $qq=mysqli_query($conn,$q);
                  $qqe=mysqli_num_rows($qq);
                  if ($qqe > 0) {
                  $no=0;
                  ?>
              <table class="table table-bordered table-striped">
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Kelas</th>
                  <th>Laporan</th>
                  <th>Absensi</th>
                  <th>Agenda</th>
                  <th>Nilai</th>
                  <th>Sertifikat</th>
                  <th>Tenggat Waktu</th>
                  <th>Aksi</th>
                </tr>
                <?php
                  while ($qqq=mysqli_fetch_array($qq)) {
                    $no++;
                    ?>
                  <tr>
                    <th><?= $no ?></th    >
                    <td class="text-truncate text-left"><?= $qqq['nama_lengkap'] ?></td>
                    <td class="text-truncate "><?= $qqq['kelas'] ?></td>
                    <td><?php if ($qqq['laporan'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                    <td><?php if ($qqq['absensi'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                    <td><?php if ($qqq['agenda'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                    <td><?php if ($qqq['nilai'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                    <td><?php if ($qqq['sertifikat'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                     <td><div class="text-danger text-truncate"><b><?php if ($qqq['deadline_pengumpulan'] == 0 || $qqq['deadline_pengumpulan'] == NULL) { echo "User Belum Login" ;}else{ echo $qqq['deadline_pengumpulan'];} ?></b></div></td>
                    <td class="text-truncate">
                      <form method="POST" action="<?= base_url('pembimbing'.'/accepting'.'/'.$jurusan.'/'.$qqq['username'].'/'.$qqq['id_assignment']) ?>">
                            <button class="btn btn-primary" onclick="return confirm('Anda Yakin?')">
                              Setujui <i class="fa fa-check"></i>
                            </button>
                      </form>
                    </td>
                  </tr>
                  <?php
                  }
                }
                else
                {
                  echo "<div class='badge badge-info'><h4>Tidak ada data siswa</h4></div>";
                }
                  ?>
              </table>
            </div>
          </div>
        </div>
        <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Daftar Siswa yang tenggat Waktu </h6>
                </div>
                <div class="card-body">
            <div class="table-responsive text-center">
                  <?php
                  include APPPATH.'views/connect.php';
                  $jurusan=$this->session->userdata('jurusan');
                  $username=$this->session->userdata('username');
                  $q="SELECT a.id_assignment,a.username,a.absensi,a.laporan,a.agenda,a.nilai,a.sertifikat,a.deadline_pengumpulan,a.status_assignment,s.nama_lengkap,s.username_pembimbing,s.kelas FROM siswa s RIGHT OUTER JOIN assignment a USING(username) WHERE s.jurusan='$jurusan' AND a.deadline_pengumpulan < '$datenow' AND s.username_pembimbing='$username' ORDER BY s.nama_lengkap ASC";
                  $qq=mysqli_query($conn,$q);
                  $qqe=mysqli_num_rows($qq);
                  if ($qqe > 0) {
                  $no=0;
                  ?>
              <table class="table table-bordered table-striped">
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Kelas</th>
                  <th>Laporan</th>
                  <th>Absensi</th>
                  <th>Agenda</th>
                  <th>Nilai</th>
                  <th>Sertifikat</th>
                  <th>Tenggat Waktu</th>
                </tr>
                <?php
                  while ($qqq=mysqli_fetch_array($qq)) {
                    $no++;
                    ?>
                  <tr>
                    <th><?= $no ?></th    >
                    <td class="text-truncate text-left"><?= $qqq['nama_lengkap'] ?></td>
                    <td class="text-truncate "><?= $qqq['kelas'] ?></td>
                    <td><?php if ($qqq['laporan'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                    <td><?php if ($qqq['absensi'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                    <td><?php if ($qqq['agenda'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                    <td><?php if ($qqq['nilai'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                    <td><?php if ($qqq['sertifikat'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                     <td><div class="text-danger text-truncate"><b><?php if ($qqq['deadline_pengumpulan'] == 0 || $qqq['deadline_pengumpulan'] == NULL) { echo "User Belum Login" ;}else{ echo $qqq['deadline_pengumpulan'];} ?></b></div></td>
                  </tr>
                  <?php
                  }
                }
                else
                {
                  echo "<div class='badge badge-info'><h4>Tidak ada data siswa</h4></div>";
                }
                  ?>
              </table>
            </div>
          </div>
        </div>
        </div>

      </div>

    <?php $this->load->view('sb_footer') ?>
      
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <?php $this->load->view('sb_modal') ?>

  <!-- Bootstrap core JavaScript-->
  <?php $this->load->view('sb_include_js') ?>
  <!-- Script JS-->

    </div>
  </div>
</body>

</html>
