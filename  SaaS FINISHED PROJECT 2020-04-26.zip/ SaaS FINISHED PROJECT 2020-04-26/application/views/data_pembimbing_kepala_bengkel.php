<?php
include APPPATH.'views/connect.php';
$jurusan = $this->session->userdata('jurusan');
?>
<!DOCTYPE html>
<html lang="en">
<title>Data Siswa | Bengkel</title>
    <?php  $this->load->view('sb_head') ?>

<body id="page-top">
  <div id="wrapper">
    <?php $this->load->view('sb_sidebar') ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php  $this->load->view('sb_topbar') ?>
        <div class="container-fluid">

          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800 ">Data Guru Pembimbing</h1>
          </div>
          <div class="card shadow mb-4">
            <div class="card-body">
              <div class="table-responsive">
              <table class="table text-center table-bordered table-striped">
                   <tr>
                     <th>No</th>
                     <th>Nama Lengkap</th>
                     <th>Username</th>
                     <th>Email</th>
                     <th class="text-truncate">Jumlah Siswa yang Dibimbing</th>
                     <th>Aksi</th>
                   </tr>
                   <?php 
                    $q="SELECT*FROM pembimbing WHERE jurusan='$jurusan'";
                    $qq=mysqli_query($conn,$q);
                    $no=0;
                    while ($qqq=mysqli_fetch_array($qq)) {
                    $no++;
                    $username_pembimbing=$qqq['username_pembimbing'];
                    $sql="SELECT * FROM siswa s WHERE username_pembimbing='$username_pembimbing'";
                    $que=mysqli_query($conn,$sql);
                    $qqn=mysqli_num_rows($que);
                   ?>
                   <tr class="text-center">
                     <th><?= $no ?></th>
                     <td class="text-truncate"><?= $qqq['nama_lengkap'] ?></td>
                     <td class="text-truncate"><?= $qqq['username_pembimbing'] ?></td>
                     <td class="text-truncate"><?= $qqq['email'] ?></td>
                     <td><?= $qqn ?> Siswa</td>
                     <td class="text-truncate"> 
                        <a href="<?= base_url('auth/deleted/'.$qqq['username_pembimbing'].'/'.$this->session->userdata('username')) ?>" onclick="return confirm('Anda Yakin ingin Menghapusnya?')" class="bg-danger rounded-circle py-2 px-2"><i class="fa fa-trash px-1 text-light"></i></a>
                     </td>
                   </tr>
                   <?php
                    }
                   ?>
              </table>
            </div>
            </div>
          </div>


        </div>

      </div>

    <?php $this->load->view('sb_footer') ?>
      
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <?php $this->load->view('sb_modal') ?>

  <!-- Bootstrap core JavaScript-->
  <?php $this->load->view('sb_include_js') ?>
  <!-- Script JS-->

    </div>
  </div>
</body>

</html>
