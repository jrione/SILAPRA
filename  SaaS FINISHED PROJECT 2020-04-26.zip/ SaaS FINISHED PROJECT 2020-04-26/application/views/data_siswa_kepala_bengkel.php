<?php
include APPPATH.'views/connect.php';
$jurusan = $this->session->userdata('jurusan');
$datenow=date('Y-m-d')
?>
<!DOCTYPE html>
<html lang="en">
<title>Data Siswa | Bengkel</title>
    <?php  $this->load->view('sb_head') ?>

<body id="page-top">
  <div id="wrapper">
    <?php $this->load->view('sb_sidebar') ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php  $this->load->view('sb_topbar') ?>
        <div class="container-fluid">

          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800 ">Data Siswa -  <?php if($this->uri->segment(4) == 'done'){ echo "Disetujui";} else{ echo "Belum Disetujui";} ?></h1>
           <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>-->
          </div>
          <div class="card shadow mb-4">
            <div class="card-body">
              <div class="table-responsive">
              <table class="table table-bordered table-striped">
                   <?php
                   $URI2=$this->uri->segment(4);
                   if ($URI2 == 'done') {
                    $qe="SELECT*,p.nama_lengkap as nama_guru,s.nama_lengkap as nama_siswa FROM pembimbing p RIGHT OUTER JOIN siswa s USING(username_pembimbing) LEFT OUTER JOIN assignment a USING(username) WHERE s.jurusan='$jurusan' AND a.deadline_pengumpulan > '$datenow' AND a.status_assignment='accepted' ORDER BY s.nama_lengkap";
                    $qqe=mysqli_query($conn,$qe);
                    $qqne=mysqli_num_rows($qqe);
                    if ($qqne == 0) { 
                      ?>
                        <center><h1 class="badge badge-info" style="font-size: 100%;">Tidak Ada Data Siswa</h1></center>
                      <?php
                     }else{
                    ?>
                   <tr>
                     <th>No</th>
                     <th>Nama Lengkap</th>
                     <th>Guru Pembimbing</th>
                     <th>Kelas</th>
                     <th>Laporan</th>
                     <th>Absensi</th>
                     <th>Agenda</th>
                     <th>Nilai</th>
                     <th>Sertifikat</th>
                     <th>Tenggat Waktu</th>
                     <th>Aksi</th>
                   </tr>
                    <?php
                      $no=0;
                      while ($qqqe=mysqli_fetch_array($qqe)) {
                      $no++;
                    ?>
                   <tr class="text-center">
                     <th><?= $no ?></th>
                     <td class="text-left text-truncate"><?= $qqqe['nama_siswa'] ?></td>
                     <td><?= $qqqe['kelas'] ?></td>
                     <td><?php if ($qqqe['laporan'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></td>
                     <td><?php if ($qqqe['absensi'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></td>
                     <td><?php if ($qqqe['agenda'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></td>
                     <td><?php if ($qqqe['nilai'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></td>
                     <td><?php if ($qqqe['sertifikat'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                     <td><div class="text-danger text-truncate"><b><?php if ($qqqe['deadline_pengumpulan'] == 0 || $qqqe['deadline_pengumpulan'] == NULL) { echo "User Belum Login" ;}else{ echo $qqqe['deadline_pengumpulan'];} ?></b></div></td>
                     <td class="text-left text-truncate">
                    <form method="POST" action="<?= base_url('kepala_bengkel/siswa/'.$jurusan.  '/updated/'.$qqqe['username_pembimbing'].'/'.$qqqe['username']) ?>">
                      <select name="username_pembimbing" class="btn">
                        <?php
                          $ee=mysqli_query($conn,"SELECT*FROM pembimbing WHERE jurusan='$jurusan'");
                          while ($eee=mysqli_fetch_array($ee)) {
                        ?>
                              <option value="<?= $eee['username_pembimbing'] ?>" 
                              <?php if ($eee['username_pembimbing'] == $qqqe['username_pembimbing']) {echo "selected"; } ?>>
                              <?= $eee['nama_lengkap'] ?>
                              </option>
                        <?php
                       }
                        ?>
                      </select>
                        <button class="bg-success btn rounded py-2 px-2" name="submit"><i class="fa fa-pen px-1 text-light"></i></button>
                    </form>
                        
                     </td>
                     <td>
                       <a href="<?= base_url('kepala_bengkel/siswa/'.$jurusan.'/deleted/'.$qqqe['username_pembimbing'].'/'.$qqqe['username']) ?>" onclick="return confirm('Anda Yakin ingin Menghapusnya?')" >
                          <button class="bg-danger btn rounded py-2 px-2">
                          <i class="fa fa-trash px-1 text-light"></i>
                          </button></a>
                     </td>
                   </tr>
                  <?php
                      } 
                     } 
                    }
                   elseif ( $URI2 == 'undone') {
                    $q="SELECT*,p.nama_lengkap as nama_guru,s.nama_lengkap as nama_siswa FROM pembimbing p RIGHT OUTER JOIN siswa s USING(username_pembimbing) LEFT OUTER JOIN assignment a USING(username) WHERE s.jurusan='$jurusan' AND a.status_assignment='waiting' AND a.deadline_pengumpulan > '$datenow' ORDER BY s.nama_lengkap";
                    $qq=mysqli_query($conn,$q);
                    $qqn=mysqli_num_rows($qq);
                    if ($qqn == 0) { 
                      ?>
                        <center><h1 class="badge badge-info" style="font-size: 100%;">Tidak Ada Data Siswa</h1></center>
                      <?php
                     }else{
                    ?>
                     <tr>
                       <th>No</th>
                       <th>Nama Lengkap</th>
                       <th>Kelas</th>
                       <th>Laporan</th>
                       <th>Absensi</th>
                       <th>Agenda</th>
                       <th>Nilai</th>
                       <th>Sertifikat</th>
                       <th>Tenggat Waktu</th>
                       <th>Guru Pembimbing</th>
                       <th>Opsi</th>
                     </tr>
                    <?php
                      $no=0;
                      while ($qqq=mysqli_fetch_array($qq)) {
                      $no++;
                    ?>
                   <tr class="text-center">
                     <th><?= $no ?></th>
                     <td class="text-left text-truncate"><?= $qqq['nama_siswa'] ?></td>
                     <td><?= $qqq['kelas']; ?></td>
                     <td><?php if ($qqq['laporan'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></td>
                     <td><?php if ($qqq['absensi'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></td>
                     <td><?php if ($qqq['agenda'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></td>
                     <td><?php if ($qqq['nilai'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></td>
                     <td><?php if ($qqq['sertifikat'] != NULL) {?> <i class="fa fa-check-circle"> <?php } ?></i></td>
                     <td><div class="text-danger text-truncate"><b><?php if ($qqq['deadline_pengumpulan'] == 0 || $qqq['deadline_pengumpulan'] == NULL) { echo "User Belum Login" ;}else{ echo $qqq['deadline_pengumpulan'];} ?></b></div></td>
                     <td class="text-left text-truncate">
                    <form method="POST" action="<?= base_url('kepala_bengkel/siswa/'.$jurusan.'/updated/'.$qqq['username_pembimbing'].'/'.$qqq['username']) ?>">
                      <select name="username_pembimbing" class="btn">
                        <?php
                          $ee=mysqli_query($conn,"SELECT*FROM pembimbing WHERE jurusan='$jurusan'");
                          while ($eee=mysqli_fetch_array($ee)) {
                        ?>
                              <option value="<?= $eee['username_pembimbing'] ?>" 
                              <?php if ($eee['username_pembimbing'] == $qqq['username_pembimbing']) {echo "selected"; } ?>>
                              <?= $eee['nama_lengkap'] ?>
                              </option>
                        <?php
                       }
                        ?>
                         </select>
                        <button class="bg-success btn rounded py-2 px-2" name="submit"><i class="fa fa-pen px-1 text-light"></i></button>
                    </form>
                        
                     </td>
                     <td>
                       <a href="<?= base_url('kepala_bengkel/siswa/'.$jurusan.'/deleted/'.$qqq['username_pembimbing'].'/'.$qqq['username']) ?>" onclick="return confirm('Anda Yakin ingin Menghapusnya?')" >
                          <button class="bg-danger btn rounded py-2 px-2">
                          <i class="fa fa-trash px-1 text-light"></i>
                          </button></a>
                     </td>
                   </tr>
                  <?php } } }?>
              </table>
            </div>
            </div>
          </div>
          

        </div>

      </div>

    <?php $this->load->view('sb_footer') ?>
      
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <?php $this->load->view('sb_modal') ?>

  <!-- Bootstrap core JavaScript-->
  <?php $this->load->view('sb_include_js') ?>
  <!-- Script JS-->

    </div>
  </div>
</body>

</html>
