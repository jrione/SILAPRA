<?php
include APPPATH.'views/connect.php';
$username=$this->session->userdata('username');
$jurusan=$this->session->userdata('jurusan');

$p="SELECT*FROM assignment WHERE username='$username'";
$pp=mysqli_query($conn,$p);
$ppp=mysqli_fetch_array($pp);


$pe="SELECT*FROM siswa WHERE username='$username' AND jurusan='$jurusan'";
$ppe=mysqli_query($conn,$pe);
$pppe=mysqli_fetch_array($ppe);

$username_pembimbing=$pppe['username_pembimbing'];
?>
<!DOCTYPE html>
<html lang="en">
<title>Home | Siswa</title>
    <?php  $this->load->view('sb_head') ?>

<body id="page-top">
  <div id="wrapper">
    <?php $this->load->view('sb_sidebar') ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php  $this->load->view('sb_topbar') ?>
        <div class="container-fluid">

          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800 ">Home</h1>
          </div>
          <?php $this->load->view('sb_content_row'); ?>
        </div>         
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Pengumpulan</h6>
            </div>
          <div class="card m-2">
            <div class="table-responsive">
              <table class="table table-striped">
                <tr class="table-bordered">
                  <th>Pengumpulan</th>
                  <th>Status Pengumpulan</th>
                  <th>Lihat</th>
                </tr>
                <tr>
                  <th><div class="badge" style="font-size: 100%">Laporan</div></th>
                  <td>
                      <div class="badge badge-info" style="font-size: 100%">
                      <?php 
                      if($ppp['laporan'] == NULL || !$ppp['laporan'] || $ppp['laporan'] == ''){ echo 'Belum Mengumpulkan';}
                      else{ echo "Mengumpulkan &nbsp;<i class='fa fa-check'></i>";  }?>
                      </div>
                  </td>
                  <td>
                      <?php if ($ppp['laporan'] == NULL || !$ppp['laporan'] || $ppp['laporan'] == '') { ?> 
                        <div class="badge badge-info text-truncate" style="font-size: 110%">Tidak Ada File
                        </div>
                      <?php }else{ ?>
                        <div class="badge text-danger text-truncate" style="font-size: 110%"><i class="fa fa-file-pdf text-danger"></i> &nbsp;
                          <a href="<?= base_url('assignment/'.$jurusan.'/'.$username_pembimbing.'/'.$username.'/'.$ppp['laporan']) ?>"> <?= $ppp['laporan'] ?></a>
                        </div>
                      <?php } ?>
                  </td>
                </tr>
                <tr>
                  <th><div class="badge" style="font-size: 100%">Absensi</div></th>
                  <td>
                      <div class="badge badge-info" style="font-size: 100%">
                      <?php 
                      if($ppp['absensi'] == NULL || !$ppp['absensi'] || $ppp['absensi'] == ''){ echo 'Belum Mengumpulkan';}
                      else{ echo "Mengumpulkan &nbsp;<i class='fa fa-check'></i>";  }?>
                      </div>
                  </td>
                  <td>
                      <?php if ($ppp['absensi'] == NULL || !$ppp['absensi'] || $ppp['absensi'] == '') { ?> 
                        <div class="badge badge-info text-truncate" style="font-size: 110%">Tidak Ada File
                        </div>
                      <?php }else{ ?>
                        <div class="badge text-danger text-truncate" style="font-size: 110%"><i class="fa fa-file-pdf text-danger"></i> &nbsp;
                          <a href="<?= base_url('assignment/'.$jurusan.'/'.$username_pembimbing.'/'.$username.'/'.$ppp['absensi']) ?>"> <?= $ppp['absensi'] ?></a>
                        </div>
                      <?php } ?>
                  </td>
                </tr>
                <tr>
                  <th><div class="badge" style="font-size: 100%">Agenda</div></th>
                  <td>
                      <div class="badge badge-info" style="font-size: 100%">
                      <?php 
                      if($ppp['agenda'] == NULL || !$ppp['agenda'] || $ppp['agenda'] == ''){ echo 'Belum Mengumpulkan';}
                      else{ echo "Mengumpulkan &nbsp;<i class='fa fa-check'></i>";  }?>
                      </div>
                  </td>
                  <td>
                      <?php if ($ppp['agenda'] == NULL || !$ppp['agenda'] || $ppp['agenda'] == '') { ?> 
                        <div class="badge badge-info text-truncate" style="font-size: 110%">Tidak Ada File
                        </div>
                      <?php }else{ ?>
                        <div class="badge text-danger text-truncate" style="font-size: 110%"><i class="fa fa-file-pdf text-danger"></i> &nbsp;
                          <a href="<?= base_url('assignment/'.$jurusan.'/'.$username_pembimbing.'/'.$username.'/'.$ppp['agenda']) ?>"> <?= $ppp['agenda'] ?></a>
                        </div>
                      <?php } ?>
                  </td>
                </tr>
                <tr>
                  <th><div class="badge" style="font-size: 100%">Nilai Prakerin</div></th>
                  <td>
                      <div class="badge badge-info" style="font-size: 100%">
                      <?php 
                      if($ppp['nilai'] == NULL || !$ppp['nilai'] || $ppp['nilai'] == ''){ echo 'Belum Mengumpulkan';}
                      else{ echo "Mengumpulkan &nbsp;<i class='fa fa-check'></i>";  }?>
                      </div>
                  </td>
                  <td>
                      <?php if ($ppp['nilai'] == NULL || !$ppp['nilai'] || $ppp['nilai'] == '') { ?> 
                        <div class="badge badge-info text-truncate" style="font-size: 110%">Tidak Ada File
                        </div>
                      <?php }else{ ?>
                        <div class="badge text-danger text-truncate" style="font-size: 110%"><i class="fa fa-file-pdf text-danger"></i> &nbsp;
                          <a href="<?= base_url('assignment/'.$jurusan.'/'.$username_pembimbing.'/'.$username.'/'.$ppp['nilai']) ?>"> <?= $ppp['nilai'] ?></a>
                        </div>
                      <?php } ?>
                  </td>
                </tr>
                <tr>
                  <th><div class="badge" style="font-size: 100%">Sertifikat</div></th>
                  <td>
                      <div class="badge badge-info" style="font-size: 100%">
                      <?php 
                      if($ppp['sertifikat'] == NULL || !$ppp['sertifikat'] || $ppp['sertifikat'] == ''){ echo 'Belum Mengumpulkan';}
                      else{ echo "Mengumpulkan &nbsp;<i class='fa fa-check'></i>";  }?>
                      </div>
                  </td>
                  <td>
                      <?php if ($ppp['sertifikat'] == NULL || !$ppp['sertifikat'] || $ppp['sertifikat'] == '') { ?> 
                        <div class="badge badge-info text-truncate" style="font-size: 110%">Tidak Ada File
                        </div>
                      <?php }else{ ?>
                        <div class="badge text-danger text-truncate" style="font-size: 110%"><i class="fa fa-file-pdf text-danger"></i> &nbsp;
                          <a href="<?= base_url('assignment/'.$jurusan.'/'.$username_pembimbing.'/'.$username.'/'.$ppp['sertifikat']) ?>"> <?= $ppp['sertifikat'] ?></a>
                        </div>
                      <?php } ?>
                  </td>
                </tr>
              </table>
            </div>
          </div>
        </div>
    </div>
  </div>
    <?php $this->load->view('sb_footer') ?>
      
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <?php $this->load->view('sb_modal') ?>

  <!-- Bootstrap core JavaScript-->
  <?php $this->load->view('sb_include_js') ?>
  <!-- Script JS-->

</body>

</html>
