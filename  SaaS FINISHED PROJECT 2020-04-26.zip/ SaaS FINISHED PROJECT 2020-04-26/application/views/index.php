<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<?php $this->load->view('sb_head') ?>
	<style type="text/css">
	</style>
	<style type="text/css">
	.btn-primary {
	    background-color: #007bff;
	    border-color: #007bff;
	}
	.masthead {
	    height: 100vh;
	    min-height: 500px;
	    background-image: url('http://localhost/bg/bg.jpg');
        background-attachment: fixed;
    	background-position: center;
    	background-repeat: no-repeat;
    	background-size: cover;
    	opacity:1;
	}
	.masthead h1{
	    color:white;
	}
	.masthead p{
	    color:white;
	}
	.lebar {
		height: 130%;
	}
	</style>
</head>
<body>
		<header class="masthead">
		  <div class="container h-100">
		    <div class="row h-100 align-items-center">
		      <div class="col-12 text-center">
		        <h1 class="font-weight-dark text-dark">Sistem Informasi Pengumpulan Laporan Prakerin</h1>
		        <p class="lead text-dark">	Pengumpulan Hasil Laporan Selama Siswa Prakerin</p>
		        <?= APPPATH ?>
                <p><a href="<?= base_url('auth/login') ?>" class="btn btn-primary btn-lg" role="button">Saya Ingin Mengumpulkan</a></p>
		      </div>
		    </div>
		  </div>
		</header>
</body>
</html>
