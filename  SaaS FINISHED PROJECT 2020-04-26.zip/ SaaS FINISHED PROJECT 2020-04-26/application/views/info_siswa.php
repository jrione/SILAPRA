<?php
$datenow=date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<title>Dashboard | Bengkel</title>
    <?php  $this->load->view('sb_head') ?>

<body id="page-top">
  <div id="wrapper">
    <?php $this->load->view('sb_sidebar') ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php  $this->load->view('sb_topbar') ?>
        <div class="container-fluid">

          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800 ">Info Siswa</h1>
          </div>
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Informasi Siswa yang Terdaftar</h6>
            </div>
            <?php
            include APPPATH.'views/connect.php';
            $jurusan=$this->session->userdata('jurusan');
            $username=$this->session->userdata('username');
            $level=$this->session->userdata('level');
            if ($level == 'kepala_bengkel') {
              $p="SELECT*FROM siswa WHERE jurusan='$jurusan' ORDER BY nama_lengkap ASC";
              $pp=mysqli_query($conn,$p);
              ?>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-bordered table-striped">
                    <tr>
                      <th class="text-truncate">No</th>
                      <th class="text-truncate">Username</th>
                      <th class="text-truncate">Nama Lengkap</th>
                      <th class="text-truncate">Kelas</th>
                      <th class="text-truncate">Email</th>
                      <th class="text-truncate">Telepon</th>
                      <th class="text-truncate">Perusahaan PKL</th>
                      <th class="text-truncate">Alamat Perusahaan</th>
                      <th class="text-truncate">Mulai PKL</th>
                      <th class="text-truncate">Selesai PKL</th>
                      <th class="text-truncate">Pembimbing Perusahaan</th>
                    </tr>
                  <?php
                  $no=0;
                  while ( $ppp=mysqli_fetch_array($pp)) {
                  $no++;
                  ?>
                    <tr>
                     <td class="text-truncate"><?= $no ?></td> 
                     <td class="text-truncate"><?= $ppp['username'] ?></td> 
                     <td class="text-truncate"><?= $ppp['nama_lengkap'] ?></td> 
                     <td class="text-truncate"><?= $ppp['kelas'] ?></td> 
                     <td class="text-truncate"><?= $ppp['email'] ?></td>  
                     <td class="text-truncate"><?= $ppp['telepon'] ?></td> 
                     <td class="text-truncate"><?= $ppp['tempat_pkl'] ?></td> 
                     <td class="text-truncate"><?= $ppp['alamat_pkl'] ?></td> 
                     <td class="text-truncate"><?= $ppp['start_pkl'] ?></td>  
                     <td class="text-truncate"><?= $ppp['finish_pkl'] ?></td> 
                     <td class="text-truncate"><?= $ppp['pembimbing_perusahaan'] ?></td>  
                    </tr>
                  <?php
                  }
                  ?>
                  </table>
                </div>
              </div>
            <?php
            }
            elseif ($level == 'pembimbing') {
            $p="SELECT*FROM siswa WHERE jurusan='$jurusan' AND username_pembimbing='$username' ORDER BY nama_lengkap ASC";
            $pp=mysqli_query($conn,$p);
            ?>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-striped">
                  <tr>
                    <th class="text-truncate">No</th>
                    <th class="text-truncate">Username</th>
                    <th class="text-truncate">Nama Lengkap</th>
                    <th class="text-truncate">Kelas</th>
                    <th class="text-truncate">Email</th>
                    <th class="text-truncate">Telepon</th>
                    <th class="text-truncate">Perusahaan PKL</th>
                    <th class="text-truncate">Alamat Perusahaan</th>
                    <th class="text-truncate">Mulai PKL</th>
                    <th class="text-truncate">Selesai PKL</th>
                    <th class="text-truncate">Pembimbing Perusahaan</th>
                  </tr>
                <?php
                $no=0;
                while ( $ppp=mysqli_fetch_array($pp)) {
                $no++;
                ?>
                  <tr>
                   <td class="text-truncate"><?= $no ?></td> 
                   <td class="text-truncate"><?= $ppp['username'] ?></td> 
                   <td class="text-truncate"><?= $ppp['nama_lengkap'] ?></td> 
                   <td class="text-truncate"><?= $ppp['kelas'] ?></td> 
                   <td class="text-truncate"><?= $ppp['email'] ?></td>  
                   <td class="text-truncate"><?= $ppp['telepon'] ?></td> 
                   <td class="text-truncate"><?= $ppp['tempat_pkl'] ?></td> 
                   <td class="text-truncate"><?= $ppp['alamat_pkl'] ?></td> 
                   <td class="text-truncate"><?= $ppp['start_pkl'] ?></td>  
                   <td class="text-truncate"><?= $ppp['finish_pkl'] ?></td> 
                   <td class="text-truncate"><?= $ppp['pembimbing_perusahaan'] ?></td>  
                  </tr>
                <?php
                }
                ?>
                </table>
              </div>
            </div>
          <?php
          }
          ?>

         </div>

        </div>
        </div>
       <?php $this->load->view('sb_footer') ?>

      </div>

      
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->

  <!-- Bootstrap core JavaScript-->
  <?php $this->load->view('sb_include_js') ?>
  <!-- Script JS-->

  <?php $this->load->view('sb_modal') ?>
    </div>
  </div>
</body>

</html>
