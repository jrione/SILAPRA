<!DOCTYPE html>
<html lang="en">
<title>Masuk</title>
<style type="text/css">
  .bg{
      background:linear-gradient(#00adb5,#11999e);
  }
</style>
    <?php   $this->load->view('sb_head') ?> 

<body class="bg" style="background-attachment: fixed;  background-repeat: no-repeat;">

<div class="container">
    <div class="row">
      <div class="col-lg-3"></div>
      <div class="col-lg-6 bg-light m-2 pb-5 " style="border-radius: 5%">
        <div class="p-4 ">
          <div class="text-center">
              <img src="<?= base_url('user_img/default/user_default.jpg') ?>" class="user-img rounded-circle">
              <h1 class="h4 text-gray-900 pb-4 mb-4">Silahkan Masuk</h1>
          </div>
          <form class="user" method="POST" action="<?= base_url('auth/proccess/login') ?>">
              <div class="input-group form-group">
                  <label id="label-1"><b>Username</b></label>
                  <input type="text" name="username" class="form-control-user" onkeyup="checkLabel('label-1',this)" onkeydown="checkLabel('label-1',this)" id="input-1" maxlength="32" required="">
              </div>
              <div class="input-group form-group">
                 <label id="label-2"><b>Password</b></label>
                  <input type="password" name="password" class="form-control-user" onkeyup="checkLabel('label-2',this)" onkeydown="checkLabel('label-2',this)"  id="passField" maxlength="32" required="">
              </div>
              <input type="checkbox" onclick="toggle()">Show Password
              <button class="btn btn-primary btn-user btn-block" name="login">
                Login
              </button>
              <hr>
          </form> 
          <a href="<?= base_url('home') ?>" class="btn btn-dark tex-right" style="float: left;">
          <i class="fa fa-arrow-left"></i> Kembali
          </a>
        </div>
      </div>
    </div>
</div>
  <!-- Bootstrap core JavaScript-->
    <?php   $this->load->view('sb_include_js') ?> 

</body>

</html>
