<?php
include APPPATH.'views/connect.php';
$nama_lengkap=$this->session->userdata('nama_lengkap');
$username=$this->session->userdata('username');
$jurusan=$this->session->userdata('jurusan');
$q="SELECT*FROM siswa WHERE jurusan='$jurusan' AND username='username'";
$qq=mysqli_query($conn,$q);
$qqq=mysqli_fetch_array($qq);
?>
<!DOCTYPE html>
<html lang="en">
<title>Masuk</title>
<style type="text/css">
  .bg{
      background:linear-gradient(#00adb5,#11999e);
  }
  .njir{
    font-size: 80%;
  }
  .njir b{
    margin-left: 7%;
  }
  .njir:hover{
    color:#007bff;
    font-size: 78%;
  }
</style>
    <?php  $this->load->view('sb_head') ?> 

<body class="bg" style="background-attachment: fixed;  background-repeat: no-repeat;">

<div class="container">
    <div class="row">
      <div class="col-lg-3"></div>
      <div class="col-lg-6 bg-light m-2 pb-5 " style="border-radius: 5%">
        <div class="p-4 ">
          <div class="text-center">
              <h4 class="h4 text-gray-900 pb-2  mb-2">
                Hai <?= $nama_lengkap ?> :)<br>
                Isi Formulir Ini Sebelum Melanjutkan
              </h4>
          </div>
          <div class="badge badge-warning text-white"><i class="fa fa-info-circle"></i> Isi Semua Dengan Benar</div>
          <form class="user" method="POST" action="<?= base_url('auth/confirm') ?>">
              <div class="input-group form-group">
                  <label id="label-1"><b>Nama Perusahaan</b></label>
                  <input type="text" name="tempat_pkl" class="form-control-user" onkeyup="checkLabel('label-1',this)" onkeydown="checkLabel('label-1',this)" id="input-1"  value="<?= $qqq['tempat_pkl'] ?>" required="">
              </div>
              <div class="input-group form-group">
                  <label id="label-prakerin"><b>Alamat Perusahaan</b></label>
                  <input type="text" name="alamat_pkl" class="form-control-user" onkeyup="checkLabel('label-prakerin',this)" onkeydown="checkLabel('label-prakerin',this)" value="<?= $qqq['pembimbing_perusahaan'] ?>" id="input-prakerin" maxlength="50" required="">
              </div>
              <div class="input-group form-group">
                  <label id="label-2"><b>Nama Pembimbing Perusahaan </b></label>
                  <input type="text" name="pembimbing_perusahaan" class="form-control-user" onkeyup="checkLabel('label-2',this)" onkeydown="checkLabel('label-2',this)" value="<?= $qqq['pembimbing_perusahaan'] ?>" id="input-2" maxlength="50" required="">
              </div>
              <div class="input-group form-group ">
                <div class="row">
                  <div class="col-sm-5">
                    <div class="njir">
                      <b>Mulai Prakerin</b>
                    <input type="date" name="start_pkl" class=" form-control-user" value="<?= $qqq['start_pkl'] ?>"  id="input-3" maxlength="32" required="">
                    </div>
                  </div>
                  <div class="col-sm-2"></div>
                  <div class="col-sm-5" style="float: right;">
                    <div class="njir">
                      <b>Selesai Prakerin</b>
                    <input type="date" name="finish_pkl" value="<?= $qqq['finish_pkl'] ?>" class=" form-control-user"  id="input-3" maxlength="32" required="">
                    </div>
                  </div>
                </div>
              </div>
              <button class="btn btn-primary btn-user btn-block" name="confirm">
                Konfirmasi
              </button>
              <hr>
          </form> 
          <a href="<?= base_url('auth/logout') ?>" onclick="return confirm('Anda Yakin ?')" class="btn btn-dark tex-right" style="float: left;">
          <i class="fa fa-arrow-left"></i> Logout
          </a>
        </div>
      </div>
    </div>
</div>
  <!-- Bootstrap core JavaScript-->
    <?php   $this->load->view('sb_include_js') ?> 

</body>

</html>
