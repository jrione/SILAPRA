<?php
include APPPATH.'views/connect.php';
$jurusan = $this->session->userdata('jurusan');
?>
<!DOCTYPE html>
<html lang="en">
<title>Dashboard | Admin</title>
    <?php  $this->load->view('sb_head') ?>
  <style>
 [type="file"] {
  height: 0;
  overflow: hidden;
  width: 0;
}

[type="file"] + label {
  background: #f15d22;
  border: none;
  border-radius: 5px;
  color: #fff;
  cursor: pointer;
  display: inline-block;
  font-family: 'Poppins', sans-serif;
  font-size: inherit;
  font-weight: 600;
  margin-bottom: 1rem;
  outline: none;
  padding: 1rem 50px;
  position: relative;
  transition: all 0.3s;
  vertical-align: middle;
  
  &:hover {
    background-color: darken(#f15d22, 10%);
  }
  
  &.btn-1 {
    background-color: #f79159;
    box-shadow: 0 6px darken(#f79159, 10%);
    transition: none;

    &:hover {
      box-shadow: 0 4px darken(#f79159, 10%);
      top: 2px;
    }
  }
  
  &.btn-2 {
    background-color: #99c793;
    border-radius: 50px;
    overflow: hidden;
    
    &::before {
      color: #fff;
      content: "\f382";
      font-family: "Font Awesome 5 Pro";
      font-size: 100%;
      height: 100%;
      right: 130%;
      line-height: 3.3;
      position: absolute;
      top: 0px;
      transition: all 0.3s;
    }

    &:hover {
      background-color: darken(#99c793, 30%);
        
      &::before {
        right: 75%;
      }
    }
  }
  
  &.btn-3 {
    background-color: #ee6d9e;
    border-radius: 0;
    overflow: hidden;
    
    span {
      display: inline-block;
      height: 100%;
      transition: all 0.3s;
      width: 100%;
    }
    
    &::before {
      color: #fff;
      content: "\f382";
      font-family: "Font Awesome 5 Pro";
      font-size: 130%;
      height: 100%;
      left: 0;
      line-height: 2.6;
      position: absolute;
      top: -180%;
      transition: all 0.3s;
      width: 100%;
    }

    &:hover {
      background-color: darken(#ee6d9e, 30%);
      
      span {
        transform: translateY(300%);
      }
        
      &::before {
        top: 0;
      }
    }
  }
}

   </style>
<body id="page-top">
  <div id="wrapper">
        <?php  $this->load->view('sb_sidebar') ?>
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <?php  $this->load->view('sb_topbar') ?>
        <div class="container-fluid">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800 ">Profile Saya</h1>
            <?php
              $username=$this->session->userdata('username');
              $q="SELECT*,p.nama_lengkap as nama_guru, s.foto_profil as foto_siswa, s.nama_lengkap as nama_siswa, s.email as email_siswa,s.telepon as telepon_siswa FROM siswa s LEFT OUTER JOIN pembimbing p USING(username_pembimbing) WHERE s.jurusan='$jurusan' AND s.username='$username'";
              $qq=mysqli_query($conn,$q);
              $qqq=mysqli_fetch_array($qq);
            ?>
          </div>
              <div class="card shadow mb-4">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-4"></div>
                    <div class="col-sm-4  text-center">
                      <img src="<?= $qqq['foto_siswa'] ?>" style="width:200px; object-fit: cover; object-position: center;" class="img-fluid rounded"  >
                      <div class="text-center">
                      <form action="<?= base_url('siswa/profile/'.$jurusan.'/foto_updated') ?>" method="post" enctype="multipart/form-data">
                          <input type="file" id="file" name="foto" required="" />
                          <label for="file" class="btn-2"/>Pilih Foto..</label>
                          <br>
                          </div>
                          <input  class="btn btn-outline-secondary bg-dark" name="ganti" value="Ganti" type="submit">
                      </form>
                    </div>
                    <div class="col-sm-4"></div>
                  </div>
                  <br>
                    <div class="row">
                      <div class="col-sm-1"></div>
                      <div class="col-sm-10">
                          <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal" action="<?= base_url('siswa/profile/'.$jurusan.'/updated') ?>" method="POST">
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="username">Username</label>
                                            <div class="col-xs-9">
                                                <input type="text" class="form-control" id="username" value="<?= $qqq['username'] ?>" name="username" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="jurusan">Jurusan</label>
                                            <div class="col-xs-9">
                                                <input type="text" class="form-control" id="jurusan" value="<?= $qqq['jurusan'] ?>" name="jurusan" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="">Nama Perusahaan Prakerin</label>
                                            <div class="col-xs-9">
                                                <input type="text" class="form-control" id="" value="<?= $qqq['tempat_pkl'] ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="nama_lengkap">Alamat Perusahaan</label>
                                            <div class="col-xs-9">
                                                <input type="text" class="form-control" id="nama_lengkap" value="<?= $qqq['alamat_pkl'] ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="nama_lengkap">Mulai Prakerin</label>
                                            <div class="col-xs-9">
                                                <input type="text" class="form-control" id="nama_lengkap" value="<?= $qqq['start_pkl'] ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="nama_lengkap">Selesai Prakerin</label>
                                            <div class="col-xs-9">
                                                <input type="text" class="form-control" id="nama_lengkap" value="<?= $qqq['finish_pkl'] ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="nama_lengkap">Nama Pembimbing Perusahaan</label>
                                            <div class="col-xs-9">
                                                <input type="text" class="form-control" id="nama_lengkap" value="<?= $qqq['pembimbing_perusahaan'] ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="nama_lengkap">Nama Lengkap</label>
                                            <div class="col-xs-9">
                                                <input type="text" class="form-control" id="nama_lengkap" value="<?= $qqq['nama_siswa'] ?>" name="nama_lengkap">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="nama_guru">Guru Pembimbing</label>
                                            <div class="col-xs-9">
                                                <input type="text" class="form-control" id="nama_guru" value="<?= $qqq['nama_guru'] ?>" name="nama_guru" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="kelas">Kelas</label>
                                            <div class="col-xs-9">
                                                <input type="text" class="form-control" id="kelas" value="<?php if($jurusan == 'RPL' || $jurusan == 'TEI' || $jurusan == 'TPTU'){ echo 'XII'; }else{ echo 'XIII'; } ?> <?= $jurusan.' '.$qqq['kelas'] ?>" name="kelas" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="email">E-mail</label>
                                            <div class="col-xs-9">
                                                <input type="email" class="form-control" id="email" value="<?=$qqq['email_siswa'] ?>" name="email">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-xs-3" for="telp">No. Telp:</label>
                                            <div class="col-xs-9">
                                                <input type="tel" pattern="{0-9}" class="form-control" id="telp" value="<?= $qqq['telepon_siswa'] ?>"maxlength="12" name="telepon">
                                            </div>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <div class="col-xs-offset-3 col-xs-9">
                                                <input type="submit" class="btn btn-primary" name="ganti" value="Ganti">
                                                <input type="reset" class="btn btn-default" value="Reset">
                                            </div>
                                        </div>
                                    </form>
                                        <hr>
                                        <form method="POST" action="<?= base_url('siswa/profile/'.$jurusan.'/password_updated') ?>">
                                            <div class="form-group">
                                                <label class="control-label col-xs-3 text-center" for="telp"><h3>Ganti Password </h3></label>
                                                <div class="col-xs-9">
                                                    <input type="password" class="form-control" id="passField" name="password" required>
                                                    <input type="checkbox" onclick="toggle()">Lihat Password<br>
                                                    <input type="submit" class="btn btn-primary" name="ganti" value="Ganti">
                                                </div>
                                            </div>
                                        </form>
                                </div>
                            </div>
                      </div>
                    </div>
                </div>
              </div>
          </div>
      </div>

<footer class="sticky-footer bg-white" style="background:linear-gradient(#00adb5,#11999e)">
  <div class="container my-auto">
    <div class="copyright text-center my-auto text-white">
      <span>Copyright &copy; Your Website 2019</span>
    </div>
  </div>
</footer>
    </div>      
  </div>
</div>
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <?php $this->load->view('sb_modal') ?>

  <!-- Bootstrap core JavaScript-->
  <?php $this->load->view('sb_include_js') ?>
  <!-- Script JS-->
</body>

</html>
