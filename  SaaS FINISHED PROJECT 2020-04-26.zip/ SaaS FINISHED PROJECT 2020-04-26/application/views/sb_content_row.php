<?php
include APPPATH.'views/connect.php';
$jurusan = $this->session->userdata('jurusan');
$this->load->view('sb_head');
$datenow=date('Y-m-d');
?>
<div class="row">


            <!-- Earnings (Monthly) Card Example -->
            <?php 
            if ($this->session->userdata('level') == 'kepala_bengkel') { 
              
            ?>
            <div class="col-xl-3 col-md-6 mb-4" >
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"> Guru Pembimbing</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800" id="guruCount">0</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-user fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php
              $w="SELECT*FROM pembimbing WHERE jurusan='$jurusan'";
              $ww=mysqli_query($conn,$w);
              $www=mysqli_num_rows($ww);
            ?>
            <script type="text/javascript">
              function jumlahGuru(id, start, end, duration) {
                  var range = end - start;
                  var current = start;
                  var increment = end > start? 1 : -1;
                  var stepTime = Math.abs(Math.floor(duration / range));
                  var obj = document.getElementById(id);
                  var timer = setInterval(function() {
                      current += increment;
                      obj.innerHTML = current;
                      if (current == end) {
                          clearInterval(timer);
                      }
                  }, stepTime);
              }
              jumlahGuru("guruCount", -1, <?= $www ?>, 1000);
            </script>
          <?php }?>


            <!-- Earnings (Monthly) Card Example -->
            <?php 
            if ($this->session->userdata('level') == 'kepala_bengkel' || $this->session->userdata('level') == 'pembimbing') { ?>
            <div class="col-xl-3 col-md-6 mb-4" >
              <div class="card border-left-info shadow h-100 py-2" >
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Siswa</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800" id="totalSiswa">0</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-user fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <script type="text/javascript">
              function jumlahSiswa(id, start, end, duration) {
                  var range = end - start;
                  var current = start;
                  var increment = end > start? 1 : -1;
                  var stepTime = Math.abs(Math.floor(duration / range));
                  var obj = document.getElementById(id);
                  var timer = setInterval(function() {
                      current += increment;
                      obj.innerHTML = current;
                      if (current == end) {
                          clearInterval(timer);
                      }
                  }, stepTime);
              }
              </script>
            <?php
              $l=$this->session->userdata('level');
              if ($l == 'kepala_bengkel') {
                  $e="SELECT*FROM siswa WHERE jurusan='$jurusan'";
                  $ee=mysqli_query($conn,$e);
                  $eee=mysqli_num_rows($ee);
                ?>
                <script type="text/javascript">
                  jumlahSiswa("totalSiswa", -1, <?= $eee ?>, 1000);
                </script>
                <?php
              }
              elseif ($l = 'pembimbing') {
                  $username=$this->session->userdata('username');
                  $e="SELECT*FROM siswa WHERE jurusan='$jurusan' AND username_pembimbing='$username'";
                  $ee=mysqli_query($conn,$e);
                  $eee=mysqli_num_rows($ee);
                ?>
                <script type="text/javascript">
                  jumlahSiswa("totalSiswa", -1, <?= $eee ?>, 1000);
                </script>
                <?php
              }
            }
          ?>

            <?php if ($this->session->userdata('level') == 'kepala_bengkel' || $this->session->userdata('level') == 'pembimbing') { ?>
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4" >
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Disetujui</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800" id="sudahCount">0</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
             <script type="text/javascript">
              function sudah(id, start, end, duration) {
                  var range = end - start;
                  var current = start;
                  var increment = end > start? 1 : -1;
                  var stepTime = Math.abs(Math.floor(duration / range));
                  var obj = document.getElementById(id);
                  var timer = setInterval(function() {
                      current += increment;
                      obj.innerHTML = current;
                      if (current == end) {
                          clearInterval(timer);
                      }
                  }, stepTime);
              }
              </script>
            <?php
              $l=$this->session->userdata('level');
              if ($l == 'kepala_bengkel') {
                  $e="SELECT*FROM assignment a RIGHT OUTER JOIN siswa s USING(username)  WHERE a.status_assignment='accepted' AND a.deadline_pengumpulan > '$datenow' AND s.jurusan='$jurusan'";
                  $ee=mysqli_query($conn,$e);
                  $eee=mysqli_num_rows($ee);
                  $eeee=mysqli_fetch_array($ee);
                ?>
                <script type="text/javascript">
                  sudah("sudahCount", -1, <?= $eee ?>, 1000);
                </script>
                <?php
              }
              elseif ($l = 'pembimbing') {
                  $username=$this->session->userdata('username');
                  $e="SELECT*FROM assignment a RIGHT OUTER JOIN siswa s USING(username)  WHERE a.status_assignment='accepted' AND a.deadline_pengumpulan > '$datenow' AND s.jurusan='$jurusan' AND s.username_pembimbing='$username'";
                  $ee=mysqli_query($conn,$e);
                  $eee=mysqli_num_rows($ee);
                  $eeee=mysqli_fetch_array($ee);
                ?>
                <script type="text/javascript">
                  sudah("sudahCount", -1, <?= $eee ?>, 1000);
                </script>
                <?php
              }
          ?>
            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4" >
              <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Belum Disetujui</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800" id="belumCount">0</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-poll fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4" >
              <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Tenggat Waktu</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800" id="lateCount">0</div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>


          </div>
          <script type="text/javascript">
              function belum(id, start, end, duration) {
                  var range = end - start;
                  var current = start;
                  var increment = end > start? 1 : -1;
                  var stepTime = Math.abs(Math.floor(duration / range));
                  var obj = document.getElementById(id);
                  var timer = setInterval(function() {
                      current += increment;
                      obj.innerHTML = current;
                      if (current == end) {
                          clearInterval(timer);
                      }
                  }, stepTime);
              }
            </script>
            <script type="text/javascript">
              function late(id, start, end, duration) {
                  var range = end - start;
                  var current = start;
                  var increment = end > start? 1 : -1;
                  var stepTime = Math.abs(Math.floor(duration / range));
                  var obj = document.getElementById(id);
                  var timer = setInterval(function() {
                      current += increment;
                      obj.innerHTML = current;
                      if (current == end) {
                          clearInterval(timer);
                      }
                  }, stepTime);
              }
              </script>
            <?php
              $l=$this->session->userdata('level');
                  $datenow=date('Y-m-d');
              if ($l == 'kepala_bengkel') {
                  $e="SELECT*FROM assignment a RIGHT OUTER JOIN siswa s USING(username)  WHERE a.status_assignment='waiting' AND s.jurusan='$jurusan' AND a.deadline_pengumpulan > '$datenow'";
                  $ee=mysqli_query($conn,$e);
                  $eee=mysqli_num_rows($ee);
                  $eeee=mysqli_fetch_array($ee);

                  $es="SELECT*FROM assignment a RIGHT OUTER JOIN siswa s USING(username) WHERE a.deadline_pengumpulan < '$datenow' AND s.jurusan='$jurusan'";
                  $ees=mysqli_query($conn,$es);
                  $eees=mysqli_num_rows($ees);
                  $eeees=mysqli_fetch_array($ees);
                ?>
                <script type="text/javascript">
                  belum("belumCount", -1, <?= $eee ?>, 1000);
                  belum("lateCount", -1, <?= $eees ?>, 1000);
                </script>
                <?php
              }
              elseif ($l = 'pembimbing') {
                  $datenow=date('Y-m-d');
                  $username=$this->session->userdata('username');
                  $e="SELECT*FROM assignment a RIGHT OUTER JOIN siswa s USING(username)  WHERE a.status_assignment='waiting' AND s.jurusan='$jurusan' AND s.username_pembimbing='$username' AND a.deadline_pengumpulan > '$datenow'";
                  $ee=mysqli_query($conn,$e);
                  $eee=mysqli_num_rows($ee);
                  $eeee=mysqli_fetch_array($ee);

                  $es="SELECT*FROM assignment a RIGHT OUTER JOIN siswa s USING(username)  WHERE a.deadline_pengumpulan < '$datenow' AND s.jurusan='$jurusan' AND s.username_pembimbing='$username'";
                  $ees=mysqli_query($conn,$es);
                  $eees=mysqli_num_rows($ees);
                  $eeees=mysqli_fetch_array($ees);
                ?>
                <script type="text/javascript">
                  belum("belumCount", -1, <?= $eee ?>, 1000);
                  belum("lateCount", -1, <?= $eees ?>, 1000);
                </script>
                <?php
              }
          ?>
        <?php 
        }
        elseif ($this->session->userdata('level') == 'siswa' ) { 
          $username=$this->session->userdata('username');
          $s="SELECT*FROM assignment a LEFT OUTER JOIN siswa s USING(username)  WHERE s.jurusan='$jurusan' AND s.username='$username'";
          $ss=mysqli_query($conn,$s);
          $ssse=mysqli_fetch_array($ss);
          $datenow=date('Y-m-d');
          ?>
          <div class="col-xl-3 col-md-6 mb-4" >
            <div class="card border-left-primary shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"> Status </div>
                      <?php 
                      if ($ssse['status_assignment'] == 'waiting' AND $ssse['deadline_pengumpulan'] > $datenow) {
                      ?>
                      <div class="h5 mb-0 font-weight-bold text-gray-800 badge badge-info text-white" style="font-size: 90%">
                        Menunggu Persetujuan
                      </div>
                      <?php
                      }
                      elseif ($ssse['status_assignment'] == 'accepted' AND $ssse['deadline_pengumpulan'] > $datenow) {
                      ?>
                      <div class="h5 mb-0 font-weight-bold text-gray-800 badge badge-success text-white" style="font-size: 90%">
                        Disetujui
                      </div>
                      <?php
                      }
                      elseif($ssse['deadline_pengumpulan'] < $datenow){
                      ?>
                      <div class="h5 mb-0 font-weight-bold text-gray-800 badge badge-danger text-white" style="font-size: 90%">
                        Tenggat Waktu
                      </div>
                      <?php
                      }
                      ?>
                  </div>
                  <div class="col-auto">
                    <i class="fas fa-user fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-md-6 mb-4" >
            <div class="card border-left-warning shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1"> Tenggat Pengumpulan</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800 badge badge-warning text-white" style="font-size: 90%"><?= $ssse['deadline_pengumpulan'] ?></div>
                  </div>
                  <div class="col-auto">
                    <i class="fas fa-book fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <?php }?>