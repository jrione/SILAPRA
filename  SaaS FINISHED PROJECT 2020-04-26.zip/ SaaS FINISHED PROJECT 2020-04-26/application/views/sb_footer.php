      <footer class="sticky-footer bg-white" style="background:linear-gradient(#00adb5,#11999e)">
        <div class="container my-auto">
          <div class="copyright text-center my-auto text-white ">
            <span>Copyright &copy; <a href="" class="text-white">zahrawaaniahmad</a> 2020</span>
          </div>
        </div>
      </footer>