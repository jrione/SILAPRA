<?php
$level=$this->session->userdata('level');
$username=$this->session->userdata('username');
include APPPATH.'views/connect.php';
$p="SELECT*FROM assignment WHERE username='$username'";
$pp=mysqli_query($conn,$p);
$ppp=mysqli_fetch_array($pp);
date_default_timezone_set('Asia/Jakarta');
$datenow=date('Y-m-d');
?>
<style type="text/css">
  .sidebar{
      background:linear-gradient(#00adb5,#11999e);
  }
</style>
   <ul class="navbar-nav sidebar sidebar-dark accordion sidebar" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('kepala_bengkel/dashboard/').$this->session->userdata('jurusan') ?>">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-file-pdf"></i>
        </div>
        <div class="sidebar-brand-text mx-1">SILAPRA</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="<?= base_url('kepala_bengkel/dashboard/').$this->session->userdata('jurusan') ?>">
          <i class="fas fa-fw <?php if ($level == 'siswa') { echo "fa-home"; } else{ echo "fa-tachometer-alt";}?>"></i>
          <span><?php if ($level == 'siswa') { echo "Home"; } else{ echo "Dashboard";} ?></span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <?php
      if ($level != 'siswa') {
      ?>
      <div class="sidebar-heading">
        DATA
      </div>
      <?php
      }
      ?>
     <?php if($this->session->userdata('level') == 'kepala_bengkel'){ ?>
      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-file-pdf"></i>
          <span>Data Siswa</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Pengumpulan Laporan:</h6>
            <a class="collapse-item" href="<?= base_url('kepala_bengkel/data_siswa/').$this->session->userdata('jurusan') ?>/undone">Belum Disetujui</a>
            <a class="collapse-item" href="<?= base_url('kepala_bengkel/data_siswa/').$this->session->userdata('jurusan') ?>/done">Disetujui</a>

          </div>
        </div>
      </li>

      <!-- Nav Item - Charts -->

      <!-- Nav Item - Tables -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsethree" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-user-plus"></i>
          <span>Tambah</span>
        </a>
        <div id="collapsethree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Pengguna</h6>
            <a class="collapse-item" href="<?= base_url('kepala_bengkel/add_user/').$this->session->userdata('jurusan') ?>/siswa">Tambah Siswa</a>
            <a class="collapse-item" href="<?= base_url('kepala_bengkel/add_user/').$this->session->userdata('jurusan') ?>/pembimbing">Tambah Guru Pembimbing</a>
          </div>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('kepala_bengkel/pembimbing/').$this->session->userdata('jurusan') ?>">
          <i class="fas fa-fw fa-user"></i>
          <span>Data Guru Pembimbing</span></a>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('kepala_bengkel/assignment/').$this->session->userdata('jurusan') ?>">
          <i class="fas fa-fw fa-folder-open"></i>
          <span>Direktori Laporan</span></a>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('kepala_bengkel/info/').$this->session->userdata('jurusan') ?>">
          <i class="fas fa-fw fa-info-circle"></i>
          <span>Info SIswa</span></a>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">
      </li>
    <?php 
      } 
      elseif ($this->session->userdata('level') == 'pembimbing') {
    ?>    
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('pembimbing/siswa/').$this->session->userdata('jurusan').'/accepted' ?>">
          <i class="fas fa-fw fa-check"></i>
          <span>Siswa yang Disetujui</span></a>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('pembimbing/assignment/').$this->session->userdata('jurusan').'/'.$username ?>">
          <i class="fas fa-fw fa-folder-open"></i>
          <span>Direktori Laporan</span></a>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('pembimbing/info/').$this->session->userdata('jurusan') ?>">
          <i class="fas fa-fw fa-info-circle"></i>
          <span>Info SIswa</span></a>
      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">
      </li>
    <?php
      }
      elseif ($this->session->userdata('level') == 'siswa') {
        $jurusan=$this->session->userdata('jurusan');
    ?>    
      <li class="nav-item">
        <?php 
        if ($datenow < $ppp['deadline_pengumpulan'] ) {
        ?>
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsethreee" aria-expanded="true" aria-controls="collapsetwo">
          <i class="fas fa-fw fa-plus"></i>
          <span>Kumpulkan</span>
        </a>
        <div id="collapsethreee" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <form method="POST" action="<?= base_url('siswa/add/'.$jurusan.'/laporan') ?>">
              <button class="btn input-group"  value="laporan" name="laporan">Laporan</button>
            </form>
            <form method="POST" action="<?= base_url('siswa/add/'.$jurusan.'/absensi') ?>">
              <button class="btn input-group" value="absensi"  name="absensi">Absensi</button>
            </form>
            <form method="POST" action="<?= base_url('siswa/add/'.$jurusan.'/agenda') ?>">
              <button class="btn input-group" value="agenda" name="agenda">Agenda</button>
            </form>
            <form method="POST" action="<?= base_url('siswa/add/'.$jurusan.'/nilai') ?>">
              <button class="btn input-group" value="nilai" name="nilai">Nilai Prakerin</button>
            </form>
            <form method="POST" action="<?= base_url('siswa/add/'.$jurusan.'/sertifikat') ?>">
              <button class="btn input-group" value="sertifikat" name="sertifikat">Sertifikat</button>
            </form>
          </div>
        </div>
      </li>
    <?php
        } 
        else{
        ?>
        <li class="nav-item">
          <a class="nav-link collapsed" href="#" onclick="alert('Batas Pengumpulan Sudah Terlewat, Anda Tidak Dapat Mengumpulkan')" data-toggle="collapse" data-target="#collapsethreee" aria-expanded="true" aria-controls="collapsetwo" style="text-decoration: none">
            <i class="fas fa-fw fa-plus"></i>
            <span class="text-white">Kumpulkan</span>
          </a>
        </li>
        <?php
        }
      }
    ?>
      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->