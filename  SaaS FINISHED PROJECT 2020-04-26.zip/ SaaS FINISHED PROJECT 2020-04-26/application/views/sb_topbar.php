
<style type="text/css">
  .i{
      background:linear-gradient(#00adb5,#11999e);
  }
</style>
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <div class="">
              <?php
              $jurusan = $this->session->userdata('jurusan');
                if ($jurusan == "SIJA") {
                  ?>
                    <h5><i class="fa fa-school"></i>&nbsp; SMKN 1 CIMAHI - SIJA</h5>
                  <?php
                }if ($jurusan == "RPL") {
                  ?>
                    <h5><i class="fa fa-school"></i>&nbsp; SMKN 1 CIMAHI - RPL</h5>
                  <?php
                }if ($jurusan == "TEI") {
                  ?>
                    <h5><i class="fa fa-school"></i>&nbsp; SMKN 1 CIMAHI - TEI</h5>
                  <?php
                }if ($jurusan == "TPTU") {
                  ?>
                    <h5><i class="fa fa-school"></i>&nbsp; SMKN 1 CIMAHI - TPTU</h5>
                  <?php
                }if ($jurusan == "TEDK") {
                  ?>
                    <h5><i class="fa fa-school"></i>&nbsp; SMKN 1 CIMAHI - TEDK</h5>
                  <?php
                }if ($jurusan == "IOP") {
                  ?>
                    <h5><i class="fa fa-school"></i>&nbsp; SMKN 1 CIMAHI - IOP</h5>
                  <?php
                }if ($jurusan == "MEKA") {
                  ?>
                    <h5><i class="fa fa-school"></i>&nbsp; SMKN 1 CIMAHI - MEKA</h5>
                  <?php
                }if ($jurusan == "PFPT") {
                  ?>
                    <h5><i class="fa fa-school"></i>&nbsp; SMKN 1 CIMAHI - PFPT</h5>
                  <?php
                }if ($jurusan == "TOI") {
                  ?>
                    <h5><i class="fa fa-school"></i>&nbsp; SMKN 1 CIMAHI - TOI</h5>
                  <?php
                }
              ?>
          </div>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php
                include APPPATH.'views/connect.php';
                $username=$this->session->userdata('username');
                $level=$this->session->userdata('level');
                $jurusan=$this->session->userdata('jurusan');
                if ($level == 'kepala_bengkel') {
                  $sql="SELECT*FROM kepala_bengkel WHERE username_kepala_bengkel='$username' AND jurusan='$jurusan'";
                  $q=mysqli_query($conn,$sql);
                  $qqq=mysqli_fetch_assoc($q);
                  ?>
                  <span class="mr-2 d-none d-lg-inline text-gray-600 small">@<?= $this->session->userdata('username') ?></span>
                  <img class="img-profile rounded-circle" src="<?= $qqq['foto_profil'] ?>" style="object-fit: cover;">
                  </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?= base_url('kepala_bengkel/profile/').$this->session->userdata('jurusan') ?>">
                  <?php
                }
                elseif ($level == 'pembimbing') {
                  $sql="SELECT*FROM pembimbing WHERE username_pembimbing='$username' AND jurusan='$jurusan'";
                  $q=mysqli_query($conn,$sql);
                  $qqq=mysqli_fetch_array($q); 
                  ?>
                  <span class="mr-2 d-none d-lg-inline text-gray-600 small">@<?= $this->session->userdata('username') ?></span>
                  <img src="<?= $qqq['foto_profil'] ?>" class="img-profile rounded-circle" style="object-fit: cover;">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?= base_url('pembimbing/profile/').$this->session->userdata('jurusan') ?>">
                  <?php
                }
                elseif ($level == 'siswa') {
                  $username=$this->session->userdata('username');
                  $sql="SELECT*FROM siswa WHERE username='$username' AND jurusan='$jurusan'";
                  $q=mysqli_query($conn,$sql);
                  $qqq=mysqli_fetch_array($q); 
                  ?>
                  <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?= $username.' - '.$qqq['nama_lengkap'] ?></span>
                  <img src="<?= $qqq['foto_profil'] ?>" class="img-profile rounded-circle" style="object-fit: cover;">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?= base_url('siswa/profile/').$this->session->userdata('jurusan') ?>">
                  <?php
                }
                ?>
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profil
                </a>
                <!--<a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
               <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log-->
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php base_url('auth/logout') ?>" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->
