  // WEEY LABELNYA INDAH
function checkLabel(labelID,input) {
	let label = document.getElementById(labelID);
	input = input;
	if (input.value != "") {
		if (!label.classList.contains('label-active')){
			label.classList.add('label-active');
		}
	}
	else{
		label.classList.remove('label-active');
	}
}


// SHOW / HIDE PASSWORD

function toggle(){
	const passField = document.getElementById("passField");
	if (passField.type === "password") {
		passField.type = "text";
	}
	else{
		passField.type = "password";
	}
}
