-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2020 at 07:06 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `c5pajri`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `id_assignment` int(11) NOT NULL,
  `username` varchar(16) DEFAULT NULL,
  `laporan` varchar(255) DEFAULT NULL,
  `absensi` varchar(255) DEFAULT NULL,
  `agenda` varchar(255) DEFAULT NULL,
  `nilai` varchar(255) DEFAULT NULL,
  `sertifikat` varchar(255) DEFAULT NULL,
  `deadline_pengumpulan` date DEFAULT NULL,
  `status_assignment` enum('waiting','accepted','outofdeadline') DEFAULT 'waiting'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`id_assignment`, `username`, `laporan`, `absensi`, `agenda`, `nilai`, `sertifikat`, `deadline_pengumpulan`, `status_assignment`) VALUES
(76, '181113955', 'laporan.Pajri Zahrawaani Ahmad-2020-04-26-p.pdf', 'absensi.Pajri Zahrawaani Ahmad-2020-04-26-1.2.1.3 Lab - Compare Data with a Hash.pdf', 'agenda.Pajri Zahrawaani Ahmad-2020-04-26-1.2.2.5 Lab - What was Taken.pdf', 'nilai.Pajri Zahrawaani Ahmad-2020-04-26-IntroCybersecurity - Additional Resources and Activities.pdf', 'sertifikat.Pajri Zahrawaani Ahmad-2020-04-26-1.4.1.1 Video - Breaking Down Stuxnet.pdf', '2020-04-29', 'accepted'),
(79, 'siswa_rpl_1', 'a', NULL, 'a', 'a', 'a', NULL, 'waiting'),
(80, 'siswa_tei_1', NULL, NULL, NULL, NULL, NULL, NULL, 'waiting'),
(81, 'siswa_sija_1', NULL, NULL, NULL, NULL, NULL, '2020-02-12', 'waiting');

-- --------------------------------------------------------

--
-- Table structure for table `kepala_bengkel`
--

CREATE TABLE `kepala_bengkel` (
  `username_kepala_bengkel` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `nama_lengkap` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telepon` varchar(12) DEFAULT NULL,
  `jurusan` varchar(5) DEFAULT NULL,
  `level` varchar(30) DEFAULT 'kepala_bengkel',
  `foto_profil` varchar(255) DEFAULT 'http://localhost/img/user_img/default/user_default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kepala_bengkel`
--

INSERT INTO `kepala_bengkel` (`username_kepala_bengkel`, `password`, `nama_lengkap`, `email`, `telepon`, `jurusan`, `level`, `foto_profil`) VALUES
('kabeng_iop', 'cd7261f3cf94bb55eea91b076b57b59e', 'kabeng_iop', NULL, NULL, 'IOP', 'kepala_bengkel', 'http://localhost/user_img/default/user_default.jpg'),
('kabeng_pfpt', 'e16e35c90277eecd0a08ab4cde1b6aaa', 'kabeng_pfpt', NULL, NULL, 'PFPT', 'kepala_bengkel', 'http://localhost/user_img/default/user_default.jpg'),
('kabeng_rpl', 'd1595cfe75ec55b86552f447f13bab86', 'kabeng_rpl', 'kabeng_rpl@gmail.com', '081809706910', 'RPL', 'kepala_bengkel', 'http://localhost/user_img/IMG_20200421-081023_kabeng_rpl.jpg'),
('kabeng_sija', '888b7527d8e45956643d3bae02f68972', 'Dodi Permana, S.pd', NULL, NULL, 'SIJA', 'kepala_bengkel', 'http://localhost/user_img/default/user_default.jpg'),
('kabeng_tedk', '13f547ecd9bfd8db711be8c52c3e9f52', 'kabeng_tei', NULL, NULL, 'TEDK', 'kepala_bengkel', 'http://localhost/user_img/default/user_default.jpg'),
('kabeng_tei', '5e11a03eb89299d9bc9f76b7114c8b84', 'kabeng_tei', NULL, NULL, 'TEI', 'kepala_bengkel', 'http://localhost/user_img/default/user_default.jpg'),
('kabeng_toi', '1281b1f31eeea2d73dd86a8927ef013c', 'kabeng_toi', NULL, NULL, 'TOI', 'kepala_bengkel', 'http://localhost/user_img/default/user_default.jpg'),
('kabeng_tptu', '95a00f7b8f9431c20265c258b137e1a4', 'kabeng_tptu', NULL, NULL, 'TPTU', 'kepala_bengkel', 'http://localhost/user_img/default/user_default.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pembimbing`
--

CREATE TABLE `pembimbing` (
  `username_pembimbing` varchar(32) NOT NULL,
  `username_kepala_bengkel` varchar(32) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `nama_lengkap` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telepon` varchar(12) DEFAULT NULL,
  `jurusan` varchar(5) DEFAULT NULL,
  `level` varchar(30) DEFAULT 'pembimbing',
  `foto_profil` varchar(255) DEFAULT 'http://localhost/user_img/default/user_default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembimbing`
--

INSERT INTO `pembimbing` (`username_pembimbing`, `username_kepala_bengkel`, `password`, `nama_lengkap`, `email`, `telepon`, `jurusan`, `level`, `foto_profil`) VALUES
('adi_setiadi', 'kabeng_sija', '81dc9bdb52d04dc20036dbd8313ed055', 'Adi Setiadi, S.Kom', 'adi_setiadi@gmail.com', NULL, 'SIJA', 'pembimbing', 'http://localhost/user_img/default/user_default.jpg'),
('antoni_budiman', 'kabeng_sija', '81dc9bdb52d04dc20036dbd8313ed055', 'Antoni Budiman, S.Pd', 'antoni_budiman@gmail.com', NULL, 'SIJA', 'pembimbing', 'http://localhost/user_img/default/user_default.jpg'),
('diky_ridwan', 'kabeng_sija', '81dc9bdb52d04dc20036dbd8313ed055', 'Diky Ridwan, S.Kom', 'dikyridwan@gmail.com', NULL, 'SIJA', 'pembimbing', 'http://localhost/user_img/default/user_default.jpg'),
('guru_rpl_1', 'kabeng_rpl', '16ef8a855e4bfbb0bc8393b8667e20c5', 'guru_rpl_1', 'guru_rpl_1@gmail.com', NULL, 'RPL', 'pembimbing', 'http://localhost/user_img/default/user_default.jpg'),
('guru_tei_1', 'kabeng_tei', '2c8e8bdee8eb730e8e59d38c628d805b', 'guru_tei_1', 'guru_tei_1@gmail.com', NULL, 'TEI', 'pembimbing', 'http://localhost/user_img/default/user_default.jpg'),
('netty_f', 'kabeng_sija', '81dc9bdb52d04dc20036dbd8313ed055', 'Netty F, S.Pd', 'netty@gmail.com', NULL, 'SIJA', 'pembimbing', 'http://localhost/user_img/default/user_default.jpg'),
('rudi_haryadi', 'kabeng_sija', '81dc9bdb52d04dc20036dbd8313ed055', 'Rudi Haryadi, S.Pd, M.Pd', 'rudi_haryadi@gmail.com', NULL, 'SIJA', 'pembimbing', 'http://localhost/user_img/default/user_default.jpg'),
('sri_prihatiningsih', 'kabeng_sija', '81dc9bdb52d04dc20036dbd8313ed055', 'DR. Sri Prihatiningsih M.Pd', 'sri_prihatiningsih@gmail.com', NULL, 'SIJA', 'pembimbing', 'http://localhost/user_img/default/user_default.jpg'),
('trimans_sija', 'kabeng_sija', '81dc9bdb52d04dc20036dbd8313ed055', 'Trimans Yogiana, S.Pd.', 'trimansyogiana@gmail.com', '081809706910', 'SIJA', 'pembimbing', 'http://localhost/user_img/IMG_20200424-095434_trimans_sija.png');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `username` varchar(32) NOT NULL,
  `username_pembimbing` varchar(32) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `nama_lengkap` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telepon` varchar(12) DEFAULT NULL,
  `jurusan` varchar(5) DEFAULT NULL,
  `kelas` varchar(1) DEFAULT NULL,
  `tempat_pkl` varchar(255) DEFAULT NULL,
  `alamat_pkl` text,
  `start_pkl` date DEFAULT NULL,
  `finish_pkl` date DEFAULT NULL,
  `pembimbing_perusahaan` varchar(255) DEFAULT NULL,
  `level` varchar(30) DEFAULT 'siswa',
  `foto_profil` varchar(255) DEFAULT 'http://localhost/user_img/default/user_default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`username`, `username_pembimbing`, `password`, `nama_lengkap`, `email`, `telepon`, `jurusan`, `kelas`, `tempat_pkl`, `alamat_pkl`, `start_pkl`, `finish_pkl`, `pembimbing_perusahaan`, `level`, `foto_profil`) VALUES
('181113955', 'trimans_sija', 'b2f08dc583b19bc9b5a9520d94b26632', 'Pajri Zahrawaani Ahmad', 'pajriblueholigand@gmail.com', '081809706910', 'SIJA', 'B', 'PT. Mitra Sinerji Teknindo', 'Metro Indah Mall Lt.3', '2019-06-12', '2019-12-21', 'Alam Suryajana, S.T', 'siswa', 'http://localhost/user_img/IMG_20200426-185337_181113955.jpg'),
('siswa_rpl_1', 'guru_rpl_1', 'bb7656761c3bf75aaf100f2aac72d305', 'siswa_rpl_1', '', NULL, 'RPL', 'A', NULL, NULL, '2020-02-02', '2020-05-22', 'Munir, S.Kom', 'siswa', 'http://localhost/user_img/default/user_default.jpg'),
('siswa_sija_1', 'trimans_sija', '81dc9bdb52d04dc20036dbd8313ed055', 'Siswa SIJA 1', '', NULL, 'SIJA', 'B', 'PT. Mitra Sinerji Teknindo', 'Metro Indah Mall Lt.3', '2019-07-12', '2020-01-12', 'Alam Suryajana, S.T', 'siswa', 'http://localhost/user_img/default/user_default.jpg'),
('siswa_tei_1', 'guru_tei_1', '0319ecee8992ebaa1ae9a24d9a3f3733', 'siswa_tei_1', '', NULL, 'TEI', 'A', NULL, NULL, '2020-02-02', '2020-04-02', 'Endang, S.T', 'siswa', 'http://localhost/user_img/default/user_default.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`id_assignment`),
  ADD KEY `username` (`username`);

--
-- Indexes for table `kepala_bengkel`
--
ALTER TABLE `kepala_bengkel`
  ADD PRIMARY KEY (`username_kepala_bengkel`);

--
-- Indexes for table `pembimbing`
--
ALTER TABLE `pembimbing`
  ADD PRIMARY KEY (`username_pembimbing`),
  ADD KEY `pembimbing_ibfk_1` (`username_kepala_bengkel`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`username`),
  ADD KEY `username_pembimbing` (`username_pembimbing`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `id_assignment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assignment`
--
ALTER TABLE `assignment`
  ADD CONSTRAINT `assignment_ibfk_1` FOREIGN KEY (`username`) REFERENCES `siswa` (`username`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pembimbing`
--
ALTER TABLE `pembimbing`
  ADD CONSTRAINT `pembimbing_ibfk_1` FOREIGN KEY (`username_kepala_bengkel`) REFERENCES `kepala_bengkel` (`username_kepala_bengkel`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `siswa`
--
ALTER TABLE `siswa`
  ADD CONSTRAINT `siswa_ibfk_1` FOREIGN KEY (`username_pembimbing`) REFERENCES `pembimbing` (`username_pembimbing`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
